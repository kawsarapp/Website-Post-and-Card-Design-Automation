import sys
import json
import io
import os
import subprocess
import tempfile
from urllib.parse import urljoin
import trafilatura
from curl_cffi import requests
from bs4 import BeautifulSoup

# ১. উইন্ডোজ/লিনাক্স কনসোল এনকোডিং ফিক্স (জরুরি)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# ইনপুট আর্গুমেন্ট চেক
try:
    url = sys.argv[1]
except IndexError:
    print(json.dumps({"error": "No URL provided"}))
    sys.exit(1)

# --- HELPER 1: FAST REQUEST (Browser Impersonation) ---
def get_html_fast(target_url):
    """
    Python দিয়ে দ্রুত পেজ লোড করার চেষ্টা করবে।
    এটি লেটেস্ট ক্রোম ব্রাউজারের মতো আচরণ করবে।
    """
    try:
        response = requests.get(
            target_url, 
            impersonate="chrome124", 
            timeout=40, 
            follow_redirects=True,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': 'bn-BD,bn;q=0.9,en-US;q=0.8,en;q=0.7',
                'Referer': 'https://www.google.com/',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Ch-Ua': '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
                'Sec-Ch-Ua-Mobile': '?0',
                'Sec-Ch-Ua-Platform': '"Windows"',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'cross-site',
                'Sec-Fetch-User': '?1'
            }
        )
        # সফল হলে এবং কন্টেন্ট সাইজ ঠিক থাকলে রিটার্ন করবে
        if response.status_code == 200 and len(response.text) > 1000:
            if response.encoding is None:
                response.encoding = response.apparent_encoding
            return response.text
    except Exception as e:
        # print(f"Debug: Fast fetch failed: {e}") 
        pass
    return None

# --- HELPER 2: HARDCORE PUPPETEER FALLBACK ---
def get_html_puppeteer(target_url):
    """
    যদি Python ফেইল করে, তবে Node.js স্ক্রিপ্ট কল করবে।
    এটি VPS-এর জন্য অপ্টিমাইজড।
    """
    try:
        # টেম্প ফাইল তৈরি
        with tempfile.NamedTemporaryFile(delete=False, suffix='.html') as tmp:
            output_path = tmp.name

        # বর্তমান ফোল্ডার থেকে JS ফাইল খুঁজবে
        script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scraper-engine.js')
        
        if not os.path.exists(script_path):
            return None

        # Node কল করা (পাথ অটোমেটিক ডিটেক্ট হবে)
        process = subprocess.run(
            ['node', script_path, target_url, output_path],
            capture_output=True, text=True
        )

        html_content = ""
        if process.returncode == 0 and os.path.exists(output_path):
            with open(output_path, 'r', encoding='utf-8') as f:
                html_content = f.read()

        # ক্লিনআপ
        if os.path.exists(output_path):
            try:
                os.remove(output_path)
            except: pass

        return html_content if len(html_content) > 500 else None
    except Exception:
        return None

# --- HELPER 3: INTELLIGENT CONTENT EXTRACTION ---
def extract_content(html, base_url):
    """
    HTML থেকে টাইটেল, বডি এবং সেরা ইমেজটি খুঁজে বের করবে।
    """
    soup = BeautifulSoup(html, 'html.parser')
    
    # ১. টাইটেল এক্সট্রাকশন
    title = ""
    if soup.find('h1'):
        title = soup.find('h1').get_text(strip=True)
    elif soup.select_one('.title'):
        title = soup.select_one('.title').get_text(strip=True)
    elif soup.title:
        title = soup.title.string
    
    # ২. ইমেজ এক্সট্রাকশন (Priority Logic)
    image = None
    
    # Priority A: Meta Tags (OG Image) - সেরা কোয়ালিটির জন্য
    if not image:
        og_img = soup.find('meta', property='og:image')
        if og_img and og_img.get('content'):
            image = og_img.get('content')

    # Priority B: JSON-LD (Google Structured Data)
    if not image:
        ld_json = soup.find_all('script', type='application/ld+json')
        for script in ld_json:
            try:
                data = json.loads(script.string)
                if 'image' in data:
                    img = data['image']
                    candidate = img['url'] if isinstance(img, dict) else (img[0] if isinstance(img, list) else img)
                    if candidate:
                        image = candidate
                        break
            except: pass
    
    # Priority C: Body Image (First Large Image)
    if not image:
        main_area = soup.select_one('article, [itemprop="articleBody"], .post-content, .entry-content, #content')
        target = main_area if main_area else soup
        
        for img in target.find_all('img'):
            src = img.get('src') or img.get('data-src')
            # লোগো বা আইকন ফিল্টার
            if src and 'logo' not in src.lower() and 'icon' not in src.lower() and 'avatar' not in src.lower() and len(src) > 20:
                # সাইজ চেক (যদি থাকে)
                width = img.get('width')
                if width and width.isdigit() and int(width) < 300: 
                    continue 
                image = urljoin(base_url, src)
                break

    # ৩. বডি টেক্সট (Trafilatura - সবথেকে ক্লিন টেক্সট দেয়)
    body = trafilatura.extract(html, include_images=False, include_comments=False, favor_precision=True)
    
    # Trafilatura ফেইল করলে ফলব্যাক (সাধারণ প্যারাগ্রাফ)
    if not body:
        paragraphs = soup.find_all('p')
        body = "\n\n".join([p.get_text(strip=True) for p in paragraphs if len(p.get_text(strip=True)) > 40])

    # HTML ফরম্যাটিং (Line break to Paragraph)
    formatted_body = ""
    if body:
        for para in body.split('\n'):
            if len(para.strip()) > 20:
                formatted_body += f"<p>{para.strip()}</p>"

    return {
        "title": title,
        "body": formatted_body,
        "image": image,
        "source_url": base_url
    }

# --- MAIN EXECUTION FLOW ---
try:
    # ধাপ ১: দ্রুত মেথডে চেষ্টা (Python)
    html = get_html_fast(url)
    data = None
    
    if html:
        extracted = extract_content(html, url)
        # যদি বডি পাওয়া যায়, তাহলে এটিই ফাইনাল
        if extracted['body'] and len(extracted['body']) > 100:
            data = extracted

    # ধাপ ২: যদি ধাপ ১ ফেইল করে বা বডি না পায় -> Puppeteer (Node.js)
    if not data:
        html_js = get_html_puppeteer(url)
        if html_js:
            data = extract_content(html_js, url)

    # ফাইনাল আউটপুট
    if data and data['body']:
        print(json.dumps(data, ensure_ascii=False))
    else:
        print(json.dumps({"error": "Failed to extract content or empty body"}))

except Exception as e:
    print(json.dumps({"error": str(e)}))