<?php

namespace App\Http\Controllers;

use App\Models\Website;
use App\Models\NewsItem;
use Illuminate\Http\Request;
use Symfony\Component\DomCrawler\Crawler;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

class WebsiteController extends Controller
{
    public function index()
    {
        if (auth()->user()->role === 'super_admin') {
            $websites = Website::withoutGlobalScopes()->get();
        } else {
            $websites = auth()->user()->accessibleWebsites()
                        ->withoutGlobalScope(\App\Models\Scopes\UserScope::class)
                        ->get();
        }
        return view('websites.index', compact('websites'));
    }

    public function store(Request $request)
    {
        if (auth()->user()->role !== 'super_admin') {
            return back()->with('error', 'আপনার ওয়েবসাইট অ্যাড করার অনুমতি নেই।');
        }

        $request->validate([
            'name' => 'required',
            'url' => 'required|url',
            'selector_container' => 'required',
            'selector_title' => 'required',
        ]);

        $data = $request->all();
        $data['user_id'] = auth()->id();

        Website::create($data);

        return back()->with('success', 'Website added successfully!');
    }

    public function scrape($id)
    {
        sleep(rand(2, 5));

        // ✅ FIX: ওয়েবসাইট এক্সেস লজিক
        if (auth()->user()->role === 'super_admin') {
            $website = Website::withoutGlobalScopes()->findOrFail($id);
        } else {
            $website = auth()->user()->accessibleWebsites()
                ->withoutGlobalScope(\App\Models\Scopes\UserScope::class)
                ->where('websites.id', $id)
                ->firstOrFail();
        }
        
        $fileName = "scrape_" . time() . "_{$website->id}.html";
        $tempFile = storage_path("app/public/{$fileName}");
        $scriptPath = base_path("scraper-engine.js");

        // ✅ JS আপডেট (Puppeteer)
        $jsCode = <<<'JS'
import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import fs from 'fs';

puppeteer.use(StealthPlugin());

const url = process.argv[2];
const outputFile = process.argv[3];

if (!url || !outputFile) process.exit(1);

(async () => {
  const browser = await puppeteer.launch({
    headless: "new",
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-blink-features=AutomationControlled',
      '--window-size=1920,1080',
      '--disable-infobars',
      '--exclude-switches=enable-automation'
    ]
  });

  try {
    const page = await browser.newPage();
    
    // User Agent Randomization
    const userAgents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
    ];
    await page.setUserAgent(userAgents[Math.floor(Math.random() * userAgents.length)]);

    await page.setViewport({ width: 1366, height: 768 });

    await page.setExtraHTTPHeaders({
        'Accept-Language': 'en-US,en;q=0.9,bn;q=0.8',
        'Upgrade-Insecure-Requests': '1',
    });

    // Resource Blocking (Ads/Media/Fonts)
    await page.setRequestInterception(true);
    page.on('request', (req) => {
        if (['font', 'media', 'stylesheet', 'image'].includes(req.resourceType())) {
            req.abort();
        } else {
            req.continue();
        }
    });

    try {
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    } catch (error) {
        console.log("Nav timeout, continuing anyway...");
    }

    // Cloudflare Bypass Wait
    await new Promise(r => setTimeout(r, 5000));

    // Smart Scroll
    await page.evaluate(async () => {
        await new Promise((resolve) => {
            let totalHeight = 0;
            const distance = 200;
            const timer = setInterval(() => {
                const scrollHeight = document.body.scrollHeight;
                window.scrollBy(0, distance);
                totalHeight += distance;
                if (totalHeight >= scrollHeight || totalHeight > 4000) { // Increased limit
                    clearInterval(timer);
                    resolve();
                }
            }, 150);
        });
    });

    // Image Data Attribute Fix
    await page.evaluate(() => {
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            const hiddenSrc = img.getAttribute('data-src') || img.getAttribute('data-original') || img.getAttribute('data-srcset');
            if (hiddenSrc) img.setAttribute('src', hiddenSrc);
        });
    });
    
    await new Promise(r => setTimeout(r, 2000));

    const html = await page.content();
    fs.writeFileSync(outputFile, html);
    
    await browser.close();
    process.exit(0);

  } catch (error) {
    console.error('Puppeteer Error:', error);
    await browser.close();
    process.exit(1);
  }
})();
JS;

        file_put_contents($scriptPath, $jsCode);

        try {
            // ✅ FIX: Node পাথ চেক করা (VPS এ অনেক সময় শুধু 'node' পায় না)
            // আপনি প্রয়োজনে এখানে '/usr/bin/node' দিতে পারেন
            $nodeCmd = trim(shell_exec("which node")); 
            if (empty($nodeCmd)) $nodeCmd = "node";

            $command = "\"$nodeCmd\" \"$scriptPath\" \"{$website->url}\" \"$tempFile\" \"{$website->selector_container}\" 2>&1";
            shell_exec($command);

            if (!file_exists($tempFile)) {
                return back()->with('error', "স্ক্র্যাপার ফাইল তৈরি হয়নি। Node.js সার্ভারে ঠিকমতো চলছে না।");
            }

            $html = file_get_contents($tempFile);
            unlink($tempFile);

            $crawler = new Crawler($html);
            
            if (str_contains($html, 'Attention Required') || str_contains($html, 'Just a moment...')) {
                return back()->with('error', "Cloudflare ব্লক দিয়েছে। ২ মিনিট পর আবার চেষ্টা করুন।");
            }

            $containers = $crawler->filter($website->selector_container);

            if ($containers->count() === 0) {
                return back()->with('error', "সিলেক্টর মিলেনি! অথবা সাইট লোড হয়নি।");
            }

            $baseTime = now(); 
            $count = 0;
            $limit = rand(5, 10);

            $containers->each(function (Crawler $node) use ($website, &$count, $baseTime, $limit) {
                if ($count >= $limit) return false;

                try {
                    $titleNode = $node->filter($website->selector_title);
                    if ($titleNode->count() === 0) return;
                    $title = trim($titleNode->text());

                    $link = null;
                    $anchor = $node->filter('a');
                    if ($anchor->count() > 0) $link = $anchor->first()->attr('href');
                    else {
                        $titleLink = $node->filter($website->selector_title)->filter('a');
                        if ($titleLink->count() > 0) $link = $titleLink->attr('href');
                    }
                    if (!$link) return;

                    if (!str_starts_with($link, 'http')) {
                        $parsedUrl = parse_url($website->url);
                        $baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
                        $link = $baseUrl . '/' . ltrim($link, '/');
                    }

                    $image = null;
                    if ($website->selector_image) {
                        try {
                            $targetNode = $node->filter($website->selector_image);
                            $image = $this->extractImageSrc($targetNode);
                        } catch (\Exception $e) {}
                    }
                    if (!$image) {
                        try {
                            $fallbackImg = $node->filter('img');
                            if ($fallbackImg->count() > 0) {
                                $image = $this->extractImageSrc($fallbackImg->first());
                            }
                        } catch (\Exception $e) {}
                    }
                    
                    if ($image) {
                        if (str_contains($image, ',')) $image = trim(explode(',', $image)[0]);
                        if (str_contains($image, ' ')) $image = trim(explode(' ', $image)[0]);
                        if (str_starts_with($image, '//')) $image = 'https:' . $image;
                        elseif (!str_starts_with($image, 'http')) {
                            $parsedUrl = parse_url($website->url);
                            $baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
                            $image = $baseUrl . '/' . ltrim($image, '/');
                        }
                    }

                    // ✅ FIX: ডাটাবেস সেভ লজিক আপডেট
                    // এখন user_id পাস করা হচ্ছে যাতে ইউজার তার স্ক্র্যাপ করা নিউজ দেখতে পায়
                    NewsItem::updateOrCreate(
                        [
                            'original_link' => $link,
                            'user_id' => Auth::id(), // ইউজারের আইডি
                        ],
                        [
                            'website_id' => $website->id,
                            'title' => $title,
                            'thumbnail_url' => $image,
                            'published_at' => $baseTime->copy()->subSeconds($count), 
                        ]
                    );
                    $count++;

                } catch (\Exception $e) {}
            });

            if ($count === 0) return back()->with('error', "কোনো নিউজ পাওয়া যায়নি।");
            
            return back()->with('success', "✅ {$count}টি নিউজ স্ক্র্যাপ হয়েছে!");

        } catch (\Exception $e) {
            return back()->with('error', 'System Error: ' . $e->getMessage());
        }
    }
    
    private function extractImageSrc($node)
    {
        if ($node->count() === 0) return null;
        $imgTag = ($node->nodeName() === 'img') ? $node : $node->filter('img');
        
        if ($imgTag->count() > 0) {
            $src = $imgTag->attr('src');
            if ($src && !str_contains($src, 'base64') && strlen($src) > 10) return $src;
            
            $attrs = ['data-original', 'data-src', 'srcset', 'data-srcset'];
            foreach ($attrs as $attr) {
                $val = $imgTag->attr($attr);
                if ($val && !str_contains($val, 'base64')) return $val;
            }
        } else {
            $style = $node->attr('style');
            if ($style && preg_match('/url\((.*?)\)/', $style, $matches)) return trim($matches[1], "'\" ");
        }
        return null;
    }
}