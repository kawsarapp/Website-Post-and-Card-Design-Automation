<?php

namespace App\Services;

use Symfony\Component\DomCrawler\Crawler;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class NewsScraperService
{
    /**
     * Main Scrape Method
     */
    public function scrape($url, $customSelectors = [], $method = 'node')
    {
        // ১. শুরুতে HTTP দিয়ে চেষ্টা
        $htmlContent = null;
        try {
            $response = Http::withHeaders([
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            ])->timeout(20)->get($url);
            
            if ($response->successful()) {
                $htmlContent = $response->body();
            }
        } catch (\Exception $e) {}

        // ২. ফেইল করলে বা বডি ছোট হলে Puppeteer
        if (empty($htmlContent) || strlen($htmlContent) < 500) {
            $htmlContent = $this->runPuppeteer($url);
        }

        if (!$htmlContent || strlen($htmlContent) < 200) {
            return null;
        }

        return $this->processHtml($htmlContent, $url, $customSelectors);
    }

    private function processHtml($html, $url, $customSelectors)
    {
        // এনকোডিং ফিক্স
        if (!mb_detect_encoding($html, 'UTF-8', true)) {
            $html = mb_convert_encoding($html, 'UTF-8', 'auto');
        }

        $crawler = new Crawler($html);
        $domain = parse_url($url, PHP_URL_HOST);

        // গার্বেজ রিমুভ
        $this->cleanGarbage($crawler);

        $data = [
            'title'      => $this->extractTitle($crawler),
            'image'      => $this->extractImage($crawler, $url),
            'body'       => null,
            'source_url' => $url
        ];

        // ৩. বডি এক্সট্রাকশন (সবচেয়ে গুরুত্বপূর্ণ পার্ট)
        $data['body'] = $this->extractBodyManually($crawler, $customSelectors, $domain);

        return !empty($data['body']) ? $data : null;
    }

    private function extractBodyManually(Crawler $crawler, $customSelectors, $domain)
    {
        // ==========================================
        // 🔥 DOMAIN SPECIFIC FIXES (AUTO-DETECT)
        // ==========================================
        $selectors = [];

        // ১. যদি যমুনা টিভি হয়
        if (str_contains($domain, 'jamuna')) {
            $selectors = ['.article-content', 'div.description', '#content-details', '.desktopSectionLead'];
        }
        // ২. যদি কালের কণ্ঠ হয়
        elseif (str_contains($domain, 'kalerkantho')) {
            $selectors = ['.details', '#details', 'div[itemprop="articleBody"]'];
        }
        // ৩. যদি যুগান্তর হয়
        elseif (str_contains($domain, 'jugantor')) {
            $selectors = ['.jw_article_body', '#myText'];
        }
        // ৪. যদি আরটিভি হয়
        elseif (str_contains($domain, 'rtv')) {
            $selectors = ['.detail-content', '.news-details'];
        }
        // ৫. যদি কালবেলা হয়
        elseif (str_contains($domain, 'kalbela')) {
            $selectors = ['.article-content', '.news-content'];
        }
        
        // ৬. সাধারণ ব্যাকআপ সিলেক্টর (Dhaka Post এবং অন্যান্যদের জন্য)
        $genericSelectors = [
            'article', 
            'div[itemprop="articleBody"]', 
            '.article-details', 
            '#content', 
            '.post-content'
        ];

        // ড্যাশবোর্ডের সিলেক্টর সবার আগে যোগ হবে
        if (!empty($customSelectors['content'])) {
            array_unshift($selectors, $customSelectors['content']);
        }

        // সব সিলেক্টর মার্জ করা হলো
        $allSelectors = array_merge($selectors, $genericSelectors);

        $bestContent = "";
        $maxLength = 0;

        foreach ($allSelectors as $selector) {
            if ($crawler->filter($selector)->count() > 0) {
                $combinedText = "";
                
                // প্যারাগ্রাফ খোঁজা
                $nodes = $crawler->filter($selector)->filterXPath('.//*[self::p or self::h3 or self::h4]');

                $nodes->each(function (Crawler $node) use (&$combinedText) {
                    $text = trim($node->text());
                    // ক্লিনিং
                    $text = preg_replace('/(প্রিন্ট|প্রকাশ|আপডেট)\s*:\s*.*?(এএম|পিএম|AM|PM)/u', '', $text);

                    if (strlen($text) > 10 && !$this->isGarbage($text)) {
                        $combinedText .= "<p>" . $text . "</p>";
                    }
                });

                // যদি প্যারাগ্রাফ না পায়, পুরো টেক্সট নেওয়া (যমুনার জন্য ব্যাকআপ)
                if (strlen($combinedText) < 100) {
                    $rawText = $crawler->filter($selector)->text();
                    if (strlen($rawText) > 150) {
                        $combinedText = "<p>" . nl2br($rawText) . "</p>";
                    }
                }

                if (strlen($combinedText) > $maxLength) {
                    $maxLength = strlen($combinedText);
                    $bestContent = $combinedText;
                }
            }
        }

        return $bestContent;
    }

    // --- SUPPORTING FUNCTIONS ---

    private function cleanGarbage(Crawler $crawler)
    {
        $crawler->filter('script, style, iframe, nav, header, footer, .advertisement, .ads, .share-buttons, .meta, .sidebar')->each(function (Crawler $node) {
            if ($node->getNode(0) && $node->getNode(0)->parentNode) {
                $node->getNode(0)->parentNode->removeChild($node->getNode(0));
            }
        });
    }

    private function extractTitle(Crawler $crawler)
    {
        if ($crawler->filter('h1')->count() > 0) return trim($crawler->filter('h1')->text());
        return null;
    }

    private function extractImage(Crawler $crawler, $url)
    {
        try {
            if ($crawler->filter('meta[property="og:image"]')->count() > 0) {
                return $crawler->filter('meta[property="og:image"]')->attr('content');
            }
        } catch (\Exception $e) {}
        return null;
    }

    public function runPuppeteer($url)
    {
        $scriptPath = base_path("scraper-universal.mjs");
        if (!file_exists($scriptPath)) $scriptPath = base_path("scraper-dynamic.mjs");
        
        if (!file_exists($scriptPath)) return null;

        $tempFile = storage_path("app/public/temp_" . time() . "_" . rand(100,999) . ".html");
        $command = "node \"$scriptPath\" \"$url\" \"$tempFile\" 2>&1";
        shell_exec($command);
        
        if (file_exists($tempFile)) {
            $content = file_get_contents($tempFile);
            unlink($tempFile);
            return $content;
        }
        return null;
    }

    private function isGarbage($text) {
        $garbage = ['আরও পড়ুন', 'বিস্তারিত', 'বিজ্ঞাপন', 'Advertisement', 'Share'];
        foreach ($garbage as $g) {
            if (stripos($text, $g) !== false) return true;
        }
        return false;
    }
}