<script>
    window.applyAdminTemplate = function(imageUrl, layoutName) {
        
        console.log("🚀 Applying Template (Manual Control Mode):", layoutName);

        // ১. সেটিংস রিসেট
        if (layoutName) {
            if(window.userSettings) {
                window.userSettings.titlePos = null;
                window.userSettings.datePos = null;
            }
        }

        // ২. ফ্রেম প্রেফারেন্স সেভ
        if (typeof window.savePreference === 'function') {
            window.savePreference('frameUrl', imageUrl);
        }

        // ৩. ক্লিনআপ
        const objects = canvas.getObjects();
        let titleObj = objects.find(obj => obj.isHeadline);
        let dateObj = objects.find(obj => obj.isDate);
        let mainImgObj = objects.find(obj => obj.isMainImage);

        for (let i = objects.length - 1; i >= 0; i--) {
            let obj = objects[i];
            if (obj.isMainImage || obj.isHeadline || obj.isDate) continue; 
            canvas.remove(obj);
        }

        // ৪. ফ্রেম লোড
        fabric.Image.fromURL(imageUrl, function(img) {
            if(!img) return;

            img.set({ 
                left: 0, top: 0, 
                scaleX: canvas.width / img.width, 
                scaleY: canvas.height / img.height, 
                selectable: false, evented: false, 
                isFrame: true 
            });

            window.frameObj = img;
            canvas.add(img);

            // ৫. লেয়ার অর্ডারিং
            if(mainImgObj) canvas.sendToBack(mainImgObj);
            canvas.bringForward(img); 
            if(titleObj) canvas.bringToFront(titleObj);
            if(dateObj) canvas.bringToFront(dateObj);

            // ==========================================
            // 🔥 ৬. আপনার কাস্টম সেটিংস (Layouts)
            // ==========================================
            const layouts = {
                
                // ১. NTV (উদাহরণ: জুম ১.০ রাখলে বক্সের সমান হবে)
                'ntv': { 
                    title: { top: 820, left: 540, width: 900, textAlign: 'center', originX: 'center' },
                    date:  { top: 100, left: 950, originX: 'right' },
                    image: { 
                        // এই বক্সে ইমেজ বসবে
                        left: 20, top: 50, width: 80, height: 50, 
                        // 🔥 জুম কন্ট্রোল: 
                        // 1.0 = বক্সের মাপে ফিট হবে (Box Fit)
                        // 1.2 = বক্সের চেয়ে একটু জুম হবে
                        // 0.9 = বক্সের চেয়ে একটু ছোট হবে (ফাঁকা থাকবে)
                        zoom: 0.5 
                    } 
                },

                // ২. RTV (উদাহরণ: একটু জুম আউট বা ছোট)
                'rtv': { 
                    title: { top: 603, left: 525, width: 950, textAlign: 'center', originX: 'center' },
                    date:  { top: 50, left: 50, originX: 'left' },
                    image: { 
                        left: 40, top: 160, width: 1000, height: 430, 
                        zoom: 0.9 // ৯০% সাইজ (একটু ফাঁকা থাকতে পারে)
                    } 
                },

                // ৩. Dhaka Post (ফুল স্ক্রিন)
                'dhakapost': { 
                    title: { top: 850, left: 540, width: 980, textAlign: 'center', originX: 'center' },
                    date:  { top: 800, left: 540, originX: 'center' },
                    image: { 
                        left: 0, top: 0, width: 1080, height: 1080, 
                        zoom: 2.0 
                    }
                },

                // ৪. ডিফল্ট
                'bottom': { 
                    title: { top: 800, left: 540, width: 980, textAlign: 'center', originX: 'center' },
                    date:  { top: 50, left: 50, originX: 'left' },
                    image: { 
                        left: 0, top: 0, width: 1080, height: 1080, 
                        zoom: 0.2 
                    }
                }
            };

            const defaultLayout = layouts['bottom'];
            const targetLayout = layouts[layoutName] || defaultLayout; 

            // ==========================================
            // 🔥 ৭. মেইন ইমেজ পজিশনিং ও ম্যানুয়াল জুম লজিক
            // ==========================================
            if (mainImgObj && targetLayout.image) {
                const imgConfig = targetLayout.image;

                // ১. ইমেজের সাইজ এবং বক্সের সাইজের অনুপাত বের করা
                const scaleX = imgConfig.width / mainImgObj.width;
                const scaleY = imgConfig.height / mainImgObj.height;
                
                // ২. বেসিক স্কেল: আমরা Math.max নিচ্ছি যাতে ইমেজটি অন্তত বক্সের এক পাশ ফিলাপ করে।
                // কিন্তু আসল কন্ট্রোল আপনার হাতে 'zoom' ভ্যালুর মাধ্যমে।
                let finalScale = Math.max(scaleX, scaleY);

                // ৩. আপনার ম্যানুয়াল জুম গুণ করা
                // যদি zoom: 1.0 দেন, তবে এটি বক্সের সাথে ফিট হবে।
                // যদি zoom: 0.5 দেন, তবে এটি বক্সের অর্ধেক সাইজ হবে।
                const customZoom = (imgConfig.zoom !== undefined) ? imgConfig.zoom : 1.0;
                
                finalScale = finalScale * customZoom;

                // ৪. ইমেজে ভ্যালু সেট করা
                mainImgObj.set({
                    scaleX: finalScale,
                    scaleY: finalScale,
                    
                    // ইমেজটি সবসময় আপনার দেওয়া বক্সের মাঝখানে (Center) থাকবে
                    left: imgConfig.left + (imgConfig.width / 2), 
                    top: imgConfig.top + (imgConfig.height / 2),
                    originX: 'center',
                    originY: 'center',
                    
                    // ক্লিপিং (ClipPath) বাদ দেওয়া হয়েছে যাতে আপনার জুম অনুযায়ী পুরো ইমেজ দেখা যায়।
                    // আপনি চাইলে আবার ক্লিপিং যোগ করতে পারেন।
                    clipPath: null 
                });
                
                mainImgObj.setCoords();
            }

            // ৮. টাইটেল পজিশন
            if(titleObj) {
                if (!window.userSettings?.titlePos || layoutName) {
                    titleObj.set({
                        top: targetLayout.title.top,
                        left: targetLayout.title.left,
                        width: targetLayout.title.width || 980,
                        textAlign: targetLayout.title.textAlign || 'center',
                        originX: targetLayout.title.originX || 'left'
                    });
                } else {
                    titleObj.set(window.userSettings.titlePos);
                }
                titleObj.setCoords();
            }

            // ৯. ডেট পজিশন
            if(dateObj) {
                if (!window.userSettings?.datePos || layoutName) {
                    dateObj.set({
                        top: targetLayout.date.top,
                        left: targetLayout.date.left,
                        originX: targetLayout.date.originX || 'left'
                    });
                } else {
                    dateObj.set(window.userSettings.datePos);
                }
                dateObj.setCoords();
            }

            canvas.requestRenderAll();
            if (typeof window.saveHistory === 'function') window.saveHistory();

        }, { crossOrigin: 'anonymous' });
    };
</script>