<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TelegramService
{
    public function send($title, $link)
    {
        $token = env('TELEGRAM_BOT_TOKEN');
        $chatId = env('TELEGRAM_CHAT_ID');

        if (!$token || !$chatId) {
            Log::warning("Telegram credentials missing in .env");
            return;
        }

        $message = "🔥 <b>{$title}</b>\n\n👇 বিস্তারিত পড়ুন:\n{$link}";

        try {
            Http::post("https://api.telegram.org/bot{$token}/sendMessage", [
                'chat_id' => $chatId,
                'text' => $message,
                'parse_mode' => 'HTML',
                'disable_web_page_preview' => false
            ]);
        } catch (\Exception $e) {
            Log::error("Telegram Send Error: " . $e->getMessage());
        }
    }
}