<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto py-8 bg-gray-100 min-h-screen">

    
    <div class="flex flex-col md:flex-row justify-between items-center mb-8">
        <div>
            <h1 class="text-3xl font-bold text-slate-800">⚡ সুপার অ্যাডমিন প্যানেল</h1>
            <p class="text-slate-500 mt-1">সিস্টেম ওভারভিউ এবং ইউজার ম্যানেজমেন্ট</p>
        </div>
        <div class="mt-4 md:mt-0">
            <span class="bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-mono shadow-md">
                Admin Mode
            </span>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow-sm" role="alert">
            <p class="font-bold">Success!</p>
            <p><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4 hover:shadow-md transition">
            <div class="p-4 bg-blue-50 text-blue-600 rounded-xl text-2xl">👥</div>
            <div>
                <p class="text-slate-500 text-sm font-bold uppercase">মোট ইউজার</p>
                <h3 class="text-3xl font-bold text-slate-800"><?php echo e($totalUsers); ?></h3>
            </div>
        </div>

        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4 hover:shadow-md transition">
            <div class="p-4 bg-purple-50 text-purple-600 rounded-xl text-2xl">📰</div>
            <div>
                <p class="text-slate-500 text-sm font-bold uppercase">জেনারেটেড নিউজ</p>
                <h3 class="text-3xl font-bold text-slate-800"><?php echo e($totalNews); ?></h3>
            </div>
        </div>

        <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4 hover:shadow-md transition">
            <div class="p-4 bg-emerald-50 text-emerald-600 rounded-xl text-2xl">🌐</div>
            <div>
                <p class="text-slate-500 text-sm font-bold uppercase">কানেক্টেড সাইট</p>
                <h3 class="text-3xl font-bold text-slate-800"><?php echo e($totalWebsites); ?></h3>
            </div>
        </div>
    </div>

    
    <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
            <h2 class="text-lg font-bold text-slate-700">👤 ইউজার লিস্ট</h2>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                        <th class="px-6 py-4 font-bold">নাম ও ইমেইল</th>
                        <th class="px-6 py-4 font-bold text-center">ক্রেডিট</th>
                        <th class="px-6 py-4 font-bold text-center">ডেইলি লিমিট</th>
                        <th class="px-6 py-4 font-bold text-center">স্ট্যাটাস</th>
                        <th class="px-6 py-4 font-bold">জয়েনিং ডেট</th>
                        <th class="px-6 py-4 font-bold text-right">অ্যাকশন</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-slate-50 transition group">
                        
                        
                        <td class="px-6 py-4">
                            <div class="font-bold text-slate-800"><?php echo e($user->name); ?></div>
                            <div class="text-sm text-slate-500"><?php echo e($user->email); ?></div>
                        </td>

                        
                        <td class="px-6 py-4 text-center">
                            <span class="bg-indigo-100 text-indigo-700 px-2 py-1 rounded text-xs font-bold inline-block min-w-[60px]">
                                <?php echo e($user->credits); ?> Left
                            </span>
                        </td>

                        
                        <td class="px-6 py-4 text-center">
                            <div class="flex items-center justify-center gap-2">
                                <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs font-bold">
                                    <?php echo e($user->daily_post_limit); ?> / Day
                                </span>
                                <button onclick="openLimitModal('<?php echo e($user->id); ?>', '<?php echo e($user->name); ?>', '<?php echo e($user->daily_post_limit); ?>')" 
                                        class="text-gray-400 hover:text-blue-600 transition p-1 rounded hover:bg-gray-200" title="Edit Limit">
                                    ✏️
                                </button>
                            </div>
                        </td>

                        
                        <td class="px-6 py-4 text-center">
                            <?php if($user->is_active): ?>
                                <span class="text-green-600 text-xs font-bold bg-green-100 px-2 py-1 rounded border border-green-200">Active</span>
                            <?php else: ?>
                                <span class="text-red-600 text-xs font-bold bg-red-100 px-2 py-1 rounded border border-red-200">Banned</span>
                            <?php endif; ?>
                        </td>

                        
                        <td class="px-6 py-4 text-sm text-slate-500">
                            <?php echo e($user->created_at->format('d M, Y')); ?>

                        </td>

                        
                        <td class="px-6 py-4 text-right flex justify-end gap-2 items-center flex-wrap">
                            
                            
                            <button onclick='openSourceModal(
                                        "<?php echo e($user->id); ?>", 
                                        "<?php echo e($user->name); ?>", 
                                        <?php echo json_encode($user->accessibleWebsites->pluck("id"), 15, 512) ?>
                                    )' 
                                    class="bg-emerald-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-emerald-700 flex items-center gap-1 shadow-sm" 
                                    title="Manage News Sources">
                                🌐 <span class="hidden md:inline">Sources</span>
                            </button>

                            
                            <button onclick='openTemplateModal(
                                        "<?php echo e($user->id); ?>", 
                                        "<?php echo e($user->name); ?>", 
                                        <?php echo json_encode($user->settings->allowed_templates ?? [], 15, 512) ?>, 
                                        "<?php echo e($user->settings->default_template ?? "dhaka_post_card"); ?>"
                                    )' 
                                    class="bg-slate-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-slate-800 flex items-center gap-1 shadow-sm" 
                                    title="Manage Templates">
                                🎨 <span class="hidden md:inline">Templates</span>
                            </button>

                            
                            <button onclick="openScraperModal('<?php echo e($user->id); ?>', '<?php echo e($user->name); ?>', '<?php echo e($user->settings->scraper_method ?? ''); ?>')" 
                                    class="bg-purple-600 text-white px-2 py-1.5 rounded-lg text-xs font-bold hover:bg-purple-700 shadow-sm flex items-center justify-center gap-1" 
                                    title="Scraper Settings">
                                🤖
                            </button>

                            
                            <form action="<?php echo e(route('admin.users.credits', $user->id)); ?>" method="POST" class="flex items-center">
                                <?php echo csrf_field(); ?>
                                <input type="number" name="amount" placeholder="+Cr" class="w-12 text-xs border border-slate-300 rounded-l-lg px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500" required>
                                <button type="submit" class="bg-indigo-600 text-white text-xs px-2 py-1.5 rounded-r-lg hover:bg-indigo-700 font-bold shadow-sm">Add</button>
                            </form>

                            
                            <form action="<?php echo e(route('admin.users.toggle', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="px-3 py-1.5 rounded-lg text-xs font-bold border shadow-sm transition <?php echo e($user->is_active ? 'border-red-200 text-red-600 hover:bg-red-50' : 'border-green-200 text-green-600 hover:bg-green-50'); ?>" onclick="return confirm('Are you sure?')">
                                    <?php echo e($user->is_active ? 'Block' : 'Unblock'); ?>

                                </button>
                            </form>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div class="p-4 bg-gray-50 border-t border-gray-200">
            <?php echo e($users->links()); ?>

        </div>
    </div>

    

    
    <div id="templateModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50 backdrop-blur-sm transition-opacity">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg mx-4 overflow-hidden transform scale-100 transition-transform">
            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h3 class="font-bold text-lg text-gray-800">Manage Templates for <span id="modalUserName" class="text-indigo-600"></span></h3>
                <button onclick="closeTemplateModal()" class="text-gray-400 hover:text-red-500 text-2xl transition">&times;</button>
            </div>
            
            <form id="templateForm" method="POST" class="p-6">
                <?php echo csrf_field(); ?>
                
                <div class="mb-5">
                    <label class="block text-sm font-bold text-gray-700 mb-2">Default Template</label>
                    <select name="default_template" class="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-indigo-500 outline-none text-sm bg-white">
                        <?php $__currentLoopData = \App\Models\UserSetting::AVAILABLE_TEMPLATES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>"><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-bold text-gray-700 mb-2">Allowed Templates</label>
                    <div class="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto p-3 border border-gray-200 rounded-lg bg-gray-50 custom-scrollbar">
                        <?php $__currentLoopData = \App\Models\UserSetting::AVAILABLE_TEMPLATES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center space-x-3 p-2 bg-white rounded border border-gray-100 cursor-pointer hover:bg-indigo-50 hover:border-indigo-200 transition">
                                <input type="checkbox" name="templates[]" value="<?php echo e($key); ?>" class="form-checkbox text-indigo-600 rounded w-4 h-4 focus:ring-indigo-500">
                                <span class="text-sm text-gray-700 font-medium"><?php echo e($name); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="flex justify-end gap-3 pt-2 border-t border-gray-100">
                    <button type="button" onclick="closeTemplateModal()" class="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg font-bold hover:bg-gray-200 transition text-sm">Cancel</button>
                    <button type="submit" class="px-6 py-2 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 transition text-sm shadow-md">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    
    <div id="limitModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50 backdrop-blur-sm">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-sm mx-4 overflow-hidden transform transition-all">
            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h3 class="font-bold text-gray-700">Set Limit for <span id="limitModalUserName" class="text-blue-600"></span></h3>
                <button onclick="closeLimitModal()" class="text-gray-400 hover:text-red-500 text-2xl transition">&times;</button>
            </div>
            
            <form id="limitForm" method="POST" class="p-6">
                <?php echo csrf_field(); ?>
                <div class="mb-6">
                    <label class="block text-sm font-bold text-gray-600 mb-2">Daily Post Limit</label>
                    <input type="number" name="limit" id="limitInput" min="1" class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none text-center text-xl font-bold text-gray-700" required>
                    <p class="text-xs text-gray-400 mt-2 text-center">এই ইউজার দিনে সর্বোচ্চ কয়টি পোস্ট করতে পারবে।</p>
                </div>

                <div class="flex justify-end gap-3">
                    <button type="button" onclick="closeLimitModal()" class="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg font-bold hover:bg-gray-200 transition text-sm">Cancel</button>
                    <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition shadow-md text-sm">Update Limit</button>
                </div>
            </form>
        </div>
    </div>

    
    <div id="sourceModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50 backdrop-blur-sm">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-lg mx-4 overflow-hidden">
            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h3 class="font-bold text-lg text-gray-800">Manage Sources for <span id="sourceModalUserName" class="text-emerald-600"></span></h3>
                <button onclick="closeSourceModal()" class="text-gray-400 hover:text-red-500 text-2xl transition">&times;</button>
            </div>
            
            <form id="sourceForm" method="POST" class="p-6">
                <?php echo csrf_field(); ?>
                <div class="mb-6">
                    <label class="block text-sm font-bold text-gray-700 mb-3">Allowed Websites</label>
                    <div class="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto p-3 border border-gray-200 rounded-lg bg-gray-50 custom-scrollbar">
                        <?php $__currentLoopData = $allWebsites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center space-x-3 p-2 bg-white rounded border border-gray-100 cursor-pointer hover:bg-emerald-50 hover:border-emerald-200 transition">
                                <input type="checkbox" name="websites[]" value="<?php echo e($site->id); ?>" class="form-checkbox text-emerald-600 rounded w-4 h-4 focus:ring-emerald-500">
                                <span class="text-sm font-medium text-gray-700"><?php echo e($site->name); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <p class="text-xs text-gray-500 mt-2 text-center bg-yellow-50 p-2 rounded border border-yellow-100">⚠️ যেসব সোর্স সিলেক্ট করবেন, ইউজার শুধুমাত্র সেগুলো থেকেই নিউজ নিতে পারবে।</p>
                </div>

                <div class="flex justify-end gap-3 pt-2 border-t border-gray-100">
                    <button type="button" onclick="closeSourceModal()" class="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg font-bold hover:bg-gray-200 transition text-sm">Cancel</button>
                    <button type="submit" class="px-6 py-2 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700 transition shadow-md text-sm">Save Access</button>
                </div>
            </form>
        </div>
    </div>

    
    <div id="scraperModal" class="fixed inset-0 bg-black/50 hidden items-center justify-center z-50 backdrop-blur-sm">
        <div class="bg-white rounded-xl shadow-2xl w-full max-w-sm mx-4 overflow-hidden transform transition-all">
            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h3 class="font-bold text-gray-700">Scraper Config: <span id="scraperUserName" class="text-purple-600"></span></h3>
                <button onclick="closeScraperModal()" class="text-gray-400 hover:text-red-500 text-2xl transition">&times;</button>
            </div>
            
            <form id="scraperForm" method="POST" class="p-6">
                <?php echo csrf_field(); ?>
                <div class="mb-6">
                    <label class="block text-sm font-bold text-gray-600 mb-2">Preferred Scraper Method</label>
                    <select name="scraper_method" id="scraperInput" class="w-full border border-gray-300 rounded-lg p-2.5 focus:ring-2 focus:ring-purple-500 outline-none text-sm bg-white">
                        <option value="">Global Default</option>
                        <option value="node">Node.js (Puppeteer) - Fast ⚡</option>
                        <option value="python">Python (Playwright) - Stable 🐍</option>
                    </select>
                    <p class="text-xs text-gray-400 mt-2">নির্দিষ্ট সাইটের জন্য স্ক্র্যাপার মেথড পরিবর্তন করতে পারেন।</p>
                </div>

                <div class="flex justify-end gap-3">
                    <button type="button" onclick="closeScraperModal()" class="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg font-bold hover:bg-gray-200 transition text-sm">Cancel</button>
                    <button type="submit" class="px-6 py-2 bg-purple-600 text-white rounded-lg font-bold hover:bg-purple-700 transition shadow-md text-sm">Save Config</button>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
    // --- Template Modal Script ---
    function openTemplateModal(userId, userName, allowedTemplates, defaultTemplate) {
        document.getElementById('modalUserName').innerText = userName;
        document.getElementById('templateForm').action = `/admin/users/${userId}/templates`;
        
        // Reset Checkboxes
        document.querySelectorAll('input[name="templates[]"]').forEach(el => el.checked = false);

        // Set Checked
        if (Array.isArray(allowedTemplates)) {
            allowedTemplates.forEach(val => {
                const checkbox = document.querySelector(`input[name="templates[]"][value="${val}"]`);
                if (checkbox) checkbox.checked = true;
            });
        }

        // Set Default
        const select = document.querySelector('select[name="default_template"]');
        if(select) select.value = defaultTemplate;

        const modal = document.getElementById('templateModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeTemplateModal() {
        const modal = document.getElementById('templateModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
    
    // --- Limit Modal Script ---
    function openLimitModal(userId, userName, currentLimit) {
        document.getElementById('limitModalUserName').innerText = userName;
        document.getElementById('limitInput').value = currentLimit;
        document.getElementById('limitForm').action = `/admin/users/${userId}/limit`;
        
        const modal = document.getElementById('limitModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeLimitModal() {
        const modal = document.getElementById('limitModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
    
    // --- Source Modal Script ---
    function openSourceModal(userId, userName, assignedWebsites) {
        document.getElementById('sourceModalUserName').innerText = userName;
        document.getElementById('sourceForm').action = `/admin/users/${userId}/websites`;
        
        // Reset
        const checkboxes = document.querySelectorAll('#sourceForm input[name="websites[]"]');
        checkboxes.forEach(el => el.checked = false);

        // Set Checked
        if (Array.isArray(assignedWebsites)) {
            assignedWebsites.forEach(id => {
                const checkbox = document.querySelector(`#sourceForm input[value="${id}"]`);
                if (checkbox) checkbox.checked = true;
            });
        }

        const modal = document.getElementById('sourceModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeSourceModal() {
        const modal = document.getElementById('sourceModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }

    // --- Scraper Modal Script (New) ---
    function openScraperModal(userId, userName, currentMethod) {
        document.getElementById('scraperUserName').innerText = userName;
        document.getElementById('scraperForm').action = `/admin/users/${userId}/scraper`;
        document.getElementById('scraperInput').value = currentMethod || "";
        
        const modal = document.getElementById('scraperModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    function closeScraperModal() {
        const modal = document.getElementById('scraperModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/asianhost/htdocs/asianhost.net/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>