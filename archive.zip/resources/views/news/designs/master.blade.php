<script>
    // Initialize the templates object
    const templates = {};
</script>

@include('news.designs.classic')
@include('news.designs.modern_split')
@include('news.designs.bold_overlay')
@include('news.designs.broadcast_tv')
@include('news.designs.glass_blur')
@include('news.designs.minimal_frame')
@include('news.designs.neon_dark')
@include('news.designs.magazine_cover')