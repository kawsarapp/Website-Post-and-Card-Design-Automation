import puppeteer from 'puppeteer';
import fs from 'fs';
const url = process.argv[2];
const outputFile = process.argv[3];
if (!url || !outputFile) process.exit(1);
(async () => {
  const browser = await puppeteer.launch({
    headless: "new",
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-blink-features=AutomationControlled', '--window-size=1920,1080']
  });
  try {
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    await page.setViewport({ width: 1366, height: 768 });
    await page.evaluateOnNewDocument(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 4 });
        Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
        const getImageData = CanvasRenderingContext2D.prototype.getImageData;
        var noise = {r: -2, g: 0, b: 2};
        CanvasRenderingContext2D.prototype.getImageData = function() {
            const imageData = getImageData.apply(this, arguments);
            for (let i = 0; i < imageData.data.length; i += 4) {
                imageData.data[i] += noise.r;
                imageData.data[i+2] += noise.b;
            }
            return imageData;
        };
    });
    try { await page.goto(url, { waitUntil: 'networkidle2', timeout: 45000 }); } catch (e) { }
    const html = await page.content();
    fs.writeFileSync(outputFile, html);
    await browser.close();
    process.exit(0);
  } catch (error) { await browser.close(); process.exit(1); }
})();