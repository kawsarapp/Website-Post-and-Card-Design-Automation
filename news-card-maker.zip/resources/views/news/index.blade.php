@extends('layouts.app')
@section('content')
<style>
    @import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&display=swap');
   
    /* Custom Scrollbar */
    .custom-scrollbar::-webkit-scrollbar { width: 5px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: #f8fafc; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #94a3b8; }

    /* Range Slider */
    input[type=range] { -webkit-appearance: none; background: transparent; }
    input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; height: 16px; width: 16px; border-radius: 50%; background: #4f46e5; cursor: pointer; margin-top: -6px; box-shadow: 0 0 0 2px white, 0 2px 4px rgba(0,0,0,0.1); }
    input[type=range]::-webkit-slider-runnable-track { width: 100%; height: 4px; cursor: pointer; background: #e2e8f0; border-radius: 2px; }
    
    .font-bangla { font-family: 'Hind Siliguri', sans-serif; }
</style>

<!-- Main Header -->
<div class="flex flex-col md:flex-row justify-between items-center mb-8 bg-gradient-to-r from-indigo-600 to-purple-700 p-6 rounded-2xl shadow-lg text-white">
    <div>
        <h2 class="text-3xl font-bold font-bangla">📰 নিউজ স্টুডিও প্রো</h2>
        <p class="text-indigo-100 text-sm opacity-90">Advanced Content Creator & Scraper</p>
    </div>
    <div class="flex gap-3 mt-4 md:mt-0">
        <a href="{{ route('websites.index') }}" class="bg-white/10 backdrop-blur-md border border-white/20 text-white px-5 py-2.5 rounded-lg hover:bg-white/20 transition flex items-center gap-2">
            ⚙️ Scraper Settings
        </a>
    </div>
</div>

<!-- News Grid -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
    @foreach($newsItems as $item)
    <div class="group bg-white rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col h-full overflow-hidden transform hover:-translate-y-1">
        
        <!-- Thumbnail Section -->
        <div class="h-48 overflow-hidden relative bg-gray-100">
            @if($item->thumbnail_url)
                <img src="{{ $item->thumbnail_url }}" alt="Thumb" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            @else
                <div class="flex items-center justify-center h-full bg-slate-100 text-slate-400">
                    <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                </div>
            @endif
            <span class="absolute top-3 left-3 bg-white/90 backdrop-blur text-xs font-bold px-2 py-1 rounded-md text-indigo-700 shadow-sm">
                {{ $item->website->name }}
            </span>
        </div>
       
        <!-- Content Section -->
        <div class="p-5 flex flex-col flex-1">
            <h3 class="text-lg font-bold leading-snug mb-3 text-gray-800 font-bangla line-clamp-2 group-hover:text-indigo-600 transition-colors">
                {{ $item->title }}
            </h3>
            
            <div class="text-xs text-gray-500 flex items-center gap-2 mb-4">
                <span class="bg-gray-100 px-2 py-1 rounded">📅 {{ $item->published_at ? \Carbon\Carbon::parse($item->published_at)->diffForHumans() : 'Just now' }}</span>
            </div>

            <div class="mt-auto grid grid-cols-2 gap-2">
                <button onclick="openGenerator('{{ addslashes($item->title) }}', '{{ $item->thumbnail_url }}', '{{ $item->website->name }}')"
                        class="col-span-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white py-2.5 rounded-lg text-sm font-bold hover:shadow-lg transition flex items-center justify-center gap-2 active:scale-95">
                    🎨 ডিজাইন করুন
                </button>
                
                @if($item->is_posted)
                    <button class="col-span-2 bg-green-50 text-green-600 py-2 rounded-lg border border-green-200 text-sm font-semibold cursor-default flex items-center justify-center gap-1">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                        Posted
                    </button>
                @else
                    <form action="{{ route('news.post', $item->id) }}" method="POST" class="w-full">
                        @csrf
                        <button type="submit" class="w-full bg-slate-800 text-white py-2 rounded-lg hover:bg-slate-900 transition text-sm font-semibold flex items-center justify-center gap-1" onclick="return confirm('পোস্ট করতে চান?')">
                            🚀 WP Post
                        </button>
                    </form>
                    <a href="{{ $item->original_link }}" target="_blank" class="bg-gray-100 text-gray-600 py-2 rounded-lg hover:bg-gray-200 transition flex items-center justify-center border border-gray-200" title="Visit Link">
                        🔗
                    </a>
                @endif
            </div>
        </div>
    </div>
    @endforeach
</div>

<div class="mt-8">
    {{ $newsItems->links() }}
</div>

<!-- STUDIO MODAL (Redesigned) -->
<div id="cardModal" class="fixed inset-0 z-50 hidden">
    <!-- Blur Backdrop -->
    <div class="absolute inset-0 bg-slate-900/90 backdrop-blur-sm transition-opacity" onclick="closeModal()"></div>

    <div class="relative w-full h-full flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl w-full max-w-[95%] h-[92vh] flex overflow-hidden shadow-2xl ring-1 ring-white/20">
            
            <!-- Sidebar Controls -->
            <div class="w-[380px] flex-shrink-0 bg-slate-50 border-r border-gray-200 flex flex-col z-20">
                
                <!-- Header -->
                <div class="p-5 border-b border-gray-200 bg-white flex justify-between items-center">
                    <h3 class="text-lg font-bold text-slate-800 flex items-center gap-2">
                        <span class="text-2xl">🎛️</span> স্টুডিও কন্ট্রোল
                    </h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-red-500 transition">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>

                <!-- Scrollable Settings -->
                <div class="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-6">
                    
                    <!-- 1. Template Select -->
                    <div class="space-y-2">
                        <label class="text-xs font-bold text-slate-500 uppercase tracking-wider">ডিজাইন টেমপ্লেট</label>
                        <div class="relative">
                            <select id="templateSelector" onchange="changeTemplate(this.value)" class="w-full pl-3 pr-10 py-3 bg-white border border-gray-300 rounded-lg text-sm font-medium focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none appearance-none cursor-pointer hover:border-indigo-300 transition shadow-sm">
                                <optgroup label="✨ New Premium">
                                    <option value="viral_bold">⚡ Viral Bold (Yellow/Black)</option>
                                    <option value="quote_pro">❝ Quote Statement</option>
                                    <option value="insta_modern">📸 Insta Modern (Square)</option>
                                </optgroup>
                                <optgroup label="📺 Standard">
                                    <option value="classic">Classic Studio</option>
                                    <option value="modern_split">Modern Split</option>
                                    <option value="bold_overlay">Breaking Red</option>
                                    <option value="broadcast_tv">TV Broadcast</option>
                                    <option value="glass_blur">Glassmorphism</option>
                                    <option value="neon_dark">Neon Dark</option>
                                </optgroup>
                            </select>
                            <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none text-gray-500">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                            </div>
                        </div>
                    </div>

                    <!-- 2. Text Content -->
                    <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm space-y-3">
                        <label class="text-xs font-bold text-slate-400 uppercase">হেডলাইন</label>
                        <textarea id="inputTitle" class="w-full bg-slate-50 border border-slate-200 p-3 rounded-lg text-base h-24 focus:ring-2 focus:ring-indigo-500 outline-none font-bangla font-bold text-slate-800 resize-none transition" oninput="updateCard()"></textarea>
                        
                        <div class="flex items-center gap-2 pt-2 border-t border-dashed border-gray-200">
                            <span class="text-xs text-slate-400">Size</span>
                            <input type="range" min="30" max="120" value="50" class="flex-1" oninput="updateFontSize(this.value)">
                        </div>
                    </div>

                    <!-- 3. Branding -->
                    <div class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm space-y-3">
                        <label class="text-xs font-bold text-slate-400 uppercase">ব্র্যান্ডিং</label>
                        <div class="flex gap-2">
                             <input type="text" id="badgeTextInput" placeholder="Topic (e.g. BREAKING)" class="w-1/2 bg-slate-50 border p-2 rounded-lg text-sm font-bold text-red-600" oninput="updateBadgeText()">
                             <input type="text" id="brandInput" value="My News" class="w-1/2 bg-slate-50 border p-2 rounded-lg text-sm font-bold text-slate-700" oninput="updateBrand()">
                        </div>
                        <div class="flex gap-2">
                            <label class="flex-1 cursor-pointer bg-indigo-50 border border-indigo-100 text-indigo-600 px-3 py-2 rounded-lg text-xs font-bold hover:bg-indigo-100 text-center flex items-center justify-center gap-1 transition">
                                <input type="file" id="logoInput" accept="image/*" onchange="uploadLogo()" class="hidden">
                                📤 Upload Logo
                            </label>
                            <button onclick="resetLogo()" class="bg-red-50 text-red-500 border border-red-100 px-3 rounded-lg hover:bg-red-100">✕</button>
                        </div>
                    </div>

                    <!-- 4. Advanced/Layout (Dynamic) -->
                    <div id="layoutControls" class="bg-white p-4 rounded-xl border border-gray-200 shadow-sm space-y-3">
                        <div class="flex justify-between items-center mb-2">
                             <label class="text-xs font-bold text-slate-400 uppercase">লেআউট স্টাইল</label>
                        </div>
                        <div class="grid grid-cols-3 gap-2">
                            <button onclick="setTextAlign('left')" class="p-2 border rounded hover:bg-gray-50 flex justify-center"><svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h10M4 18h7"></path></svg></button>
                            <button onclick="setTextAlign('center')" class="p-2 border rounded hover:bg-gray-50 flex justify-center"><svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg></button>
                            <button onclick="setTextAlign('right')" class="p-2 border rounded hover:bg-gray-50 flex justify-center"><svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 6H4M20 12H10M20 18H13"></path></svg></button>
                        </div>
                        
                        <!-- Theme Colors -->
                        <div class="flex justify-between gap-2 mt-3 pt-3 border-t border-gray-100">
                             <button onclick="setThemeColor('red')" class="w-8 h-8 rounded-full bg-red-600 ring-2 ring-offset-2 ring-transparent hover:ring-red-300"></button>
                             <button onclick="setThemeColor('blue')" class="w-8 h-8 rounded-full bg-blue-600 ring-2 ring-offset-2 ring-transparent hover:ring-blue-300"></button>
                             <button onclick="setThemeColor('emerald')" class="w-8 h-8 rounded-full bg-emerald-600 ring-2 ring-offset-2 ring-transparent hover:ring-emerald-300"></button>
                             <button onclick="setThemeColor('purple')" class="w-8 h-8 rounded-full bg-purple-600 ring-2 ring-offset-2 ring-transparent hover:ring-purple-300"></button>
                             <button onclick="setThemeColor('black')" class="w-8 h-8 rounded-full bg-black ring-2 ring-offset-2 ring-transparent hover:ring-gray-300"></button>
                        </div>
                    </div>

                </div>

                <!-- Footer Action -->
                <div class="p-5 border-t border-gray-200 bg-white">
                    <button id="downloadBtn" onclick="downloadCard()" class="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-3.5 rounded-xl font-bold text-lg hover:from-green-700 hover:to-emerald-700 shadow-lg hover:shadow-green-500/30 transition transform active:scale-[0.98] flex items-center justify-center gap-2">
                        📥 ছবি ডাউনলোড করুন
                    </button>
                </div>
            </div>

            <!-- Preview Canvas Area -->
            <div class="flex-1 bg-slate-900 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] flex items-center justify-center overflow-auto relative p-10">
                <!-- Zoom Controls -->
                <div class="absolute top-6 right-6 flex bg-white/10 backdrop-blur rounded-lg border border-white/20 p-1 gap-1">
                    <button onclick="changeZoom(-0.1)" class="w-8 h-8 flex items-center justify-center text-white hover:bg-white/20 rounded">-</button>
                    <button onclick="resetZoom()" class="w-8 h-8 flex items-center justify-center text-white font-bold text-xs">100%</button>
                    <button onclick="changeZoom(0.1)" class="w-8 h-8 flex items-center justify-center text-white hover:bg-white/20 rounded">+</button>
                </div>

                <div id="preview-wrapper" class="shadow-2xl transition-transform duration-200 ease-out origin-center ring-8 ring-black/20">
                    <div id="canvas-container" class="bg-white relative flex flex-col overflow-hidden"
                         style="width: 1080px; height: 1080px; flex-shrink: 0;">
                         <!-- Content injected by JS -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
    // --- STATE MANAGEMENT ---
    const modal = document.getElementById('cardModal');
    const proxyRoute = "{{ route('proxy.image') }}";
    
    let state = {
        title: "",
        image: "",
        badge: "NEWS",
        brand: "My News",
        date: "",
        logo: null,
        themeColor: 'red', // red, blue, emerald, purple, black
        zoom: 0.55
    };
    
    let currentTemplate = 'viral_bold'; // Default new template

    // --- TEMPLATES ---
    // All templates use state.themeColor to allow color changing
    const getThemeClass = (type) => {
        const colors = {
            red: { bg: 'bg-red-600', text: 'text-red-600', border: 'border-red-600' },
            blue: { bg: 'bg-blue-600', text: 'text-blue-600', border: 'border-blue-600' },
            emerald: { bg: 'bg-emerald-600', text: 'text-emerald-600', border: 'border-emerald-600' },
            purple: { bg: 'bg-purple-700', text: 'text-purple-700', border: 'border-purple-700' },
            black: { bg: 'bg-black', text: 'text-black', border: 'border-black' }
        };
        return colors[state.themeColor] || colors['red'];
    }

    const templates = {
        // --- NEW 1: VIRAL BOLD (High Contrast) ---
        viral_bold: () => {
            const c = getThemeClass();
            return `
            <div class="w-full h-full bg-[#111] flex flex-col relative font-bangla">
                <div class="h-[65%] w-full relative overflow-hidden group">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover opacity-90 transition-transform duration-1000 group-hover:scale-105">
                    <div class="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#111]"></div>
                    
                    <div class="absolute top-10 left-10">
                        <div class="${c.bg} text-white px-6 py-2 text-2xl font-black italic uppercase tracking-wider transform -skew-x-12 inline-block shadow-[4px_4px_0px_0px_rgba(255,255,255,0.2)]" id="textBadge">
                            ${state.badge}
                        </div>
                    </div>
                </div>
                
                <div class="h-[35%] w-full p-12 flex flex-col justify-start relative z-10">
                     <div class="w-24 h-2 ${c.bg} mb-6"></div>
                     <h1 id="cardTitle" class="text-[65px] font-bold text-white leading-[1.15] mb-4 drop-shadow-xl text-left">
                        ${state.title}
                     </h1>
                     <div class="mt-auto pt-6 border-t border-gray-800 flex justify-between items-center text-gray-400">
                        <div class="flex items-center gap-3">
                            <div id="logoWrapper" class="hidden"><img id="logoImg" src="" class="h-12 w-auto"></div>
                            <span class="text-2xl font-bold uppercase tracking-widest text-white" id="brandNameDisplay">${state.brand}</span>
                        </div>
                        <span class="text-2xl font-mono">${state.date}</span>
                     </div>
                </div>
            </div>`;
        },

        // --- NEW 2: QUOTE PRO (Statement Focus) ---
        quote_pro: () => {
             const c = getThemeClass();
             return `
             <div class="w-full h-full bg-slate-50 border-[20px] border-white relative font-bangla flex flex-col">
                <div class="h-[55%] relative overflow-hidden m-4 rounded-3xl">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover grayscale-[20%] hover:grayscale-0 transition duration-700">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-transparent to-transparent"></div>
                    <div class="absolute bottom-8 left-8 text-white/80 font-bold text-xl uppercase tracking-[0.2em] border-l-4 ${c.border} pl-4">
                        ${state.badge}
                    </div>
                </div>
                
                <div class="h-[45%] px-16 py-8 flex flex-col justify-center relative">
                    <div class="absolute -top-10 right-16 text-[180px] leading-none ${c.text} opacity-20 font-serif">”</div>
                    
                    <h1 id="cardTitle" class="text-[55px] font-bold text-slate-800 leading-tight z-10 text-center italic">
                        ${state.title}
                    </h1>
                    
                    <div class="w-full flex justify-center mt-10">
                        <div class="px-8 py-3 bg-white border border-slate-200 rounded-full shadow-sm flex items-center gap-4">
                             <div id="logoWrapper" class="hidden"><img id="logoImg" src="" class="h-8 w-auto"></div>
                             <span class="text-xl font-bold ${c.text} uppercase" id="brandNameDisplay">${state.brand}</span>
                             <span class="w-1 h-6 bg-gray-200"></span>
                             <span class="text-lg text-gray-500 font-bold">${state.date}</span>
                        </div>
                    </div>
                </div>
             </div>`;
        },

        // --- NEW 3: INSTA MODERN (Clean Square) ---
        insta_modern: () => {
             const c = getThemeClass();
             return `
             <div class="w-full h-full bg-white relative font-bangla p-10 flex flex-col items-center justify-center">
                <div class="w-full h-full border border-gray-100 rounded-[50px] shadow-2xl overflow-hidden relative bg-gray-900">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover opacity-60">
                    <div class="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/10"></div>
                    
                    <!-- Top Bar -->
                    <div class="absolute top-0 w-full p-10 flex justify-between items-center">
                        <div class="flex items-center gap-3 bg-white/10 backdrop-blur px-5 py-2 rounded-full border border-white/10">
                             <div class="w-3 h-3 ${c.bg} rounded-full animate-pulse"></div>
                             <span class="text-white font-bold text-xl uppercase tracking-wider">${state.badge}</span>
                        </div>
                        <div id="logoWrapper" class="hidden"><img id="logoImg" src="" class="h-14 w-auto drop-shadow-lg"></div>
                    </div>

                    <!-- Bottom Content -->
                    <div class="absolute bottom-0 w-full p-12 pb-16">
                        <h1 id="cardTitle" class="text-[60px] font-bold text-white leading-tight mb-8 drop-shadow-lg border-l-8 ${c.border} pl-8">
                            ${state.title}
                        </h1>
                        <div class="flex items-center gap-4 text-gray-300 ml-8">
                             <span class="font-bold text-2xl text-white" id="brandNameDisplay">${state.brand}</span>
                             <span>•</span>
                             <span class="text-xl">${state.date}</span>
                        </div>
                    </div>
                </div>
             </div>`;
        },

        // --- EXISTING CLASSIC (Upgraded) ---
        classic: () => {
            const c = getThemeClass();
            return `
            <div class="flex flex-col h-full bg-white font-bangla">
                <div class="h-[60%] relative overflow-hidden">
                     <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover">
                     <div class="absolute bottom-0 left-0 w-full h-1/3 bg-gradient-to-t from-black/50 to-transparent"></div>
                     <div class="absolute top-8 left-8 ${c.bg} text-white px-6 py-2 text-3xl font-bold uppercase shadow-lg">${state.badge}</div>
                </div>
                <div class="h-[40%] px-12 flex flex-col justify-center items-center text-center bg-white text-slate-900 relative">
                     <div class="w-20 h-2 ${c.bg} mb-6 rounded-full"></div>
                     <h1 id="cardTitle" class="text-[55px] font-bold leading-snug line-clamp-4">${state.title}</h1>
                     <div class="absolute bottom-6 w-full px-12 flex justify-between border-t border-gray-100 pt-4 text-gray-500">
                        <span class="text-2xl font-bold uppercase ${c.text}" id="brandNameDisplay">${state.brand}</span>
                        <span class="text-2xl font-semibold">${state.date}</span>
                     </div>
                </div>
            </div>`;
        },

        // --- MODERN SPLIT (Upgraded) ---
        modern_split: () => {
             const c = getThemeClass();
             return `
             <div class="flex h-full w-full bg-white relative font-bangla">
                <div class="w-1/2 h-full relative overflow-hidden">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover">
                    <div class="absolute inset-0 bg-black/10"></div>
                </div>
                <div class="w-1/2 h-full p-16 flex flex-col justify-center bg-slate-50 relative">
                    <div class="absolute top-0 right-0 w-32 h-32 ${c.bg} opacity-10 rounded-bl-[100px]"></div>
                    <div class="w-full mb-8">
                        <span class="${c.text} border ${c.border} px-4 py-1 text-xl font-bold uppercase tracking-widest rounded bg-white" id="textBadge">${state.badge}</span>
                    </div>
                    <h1 id="cardTitle" class="text-[60px] font-extrabold text-slate-900 leading-[1.2] mb-10 text-left">
                        ${state.title}
                    </h1>
                    <div class="mt-auto border-t-2 border-slate-200 pt-8 flex justify-between items-center text-slate-500">
                         <div class="flex items-center gap-2">
                             <div id="logoWrapper" class="hidden"><img id="logoImg" src="" class="h-12 w-auto"></div>
                             <span class="text-2xl font-bold uppercase text-slate-800 tracking-wider" id="brandNameDisplay">${state.brand}</span>
                         </div>
                         <span class="text-2xl font-medium">${state.date}</span>
                    </div>
                </div>
            </div>`;
        },

        // --- BOLD OVERLAY ---
        bold_overlay: () => {
             const c = getThemeClass();
             return `
             <div class="relative h-full w-full overflow-hidden bg-black font-bangla">
                <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover opacity-70">
                <div class="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                <div class="absolute top-0 w-full h-4 ${c.bg}"></div>
                
                <div class="absolute bottom-0 w-full p-20 flex flex-col items-start justify-end h-full">
                    <div class="${c.bg} text-white font-bold px-6 py-2 text-2xl mb-6 uppercase tracking-widest inline-block skew-x-[-10deg] shadow-lg">
                        <span class="skew-x-[10deg] inline-block">${state.badge}</span>
                    </div>
                    <h1 id="cardTitle" class="text-[80px] font-black text-white leading-tight drop-shadow-2xl text-left border-l-[12px] ${c.border} pl-10">
                        ${state.title}
                    </h1>
                    <div class="w-full flex justify-between items-center mt-12 text-gray-300 border-t border-white/20 pt-8">
                        <span class="text-4xl font-bold text-white tracking-widest uppercase" id="brandNameDisplay">${state.brand}</span>
                        <span class="text-3xl font-light">${state.date}</span>
                    </div>
                </div>
            </div>`;
        },
        
        // --- TV BROADCAST ---
        broadcast_tv: () => {
             const c = getThemeClass();
             return `
            <div class="relative h-full w-full bg-gray-900 overflow-hidden font-bangla">
                <div class="h-[82%] w-full relative">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover">
                     <div class="absolute top-10 left-10 flex items-center gap-4">
                         <div class="bg-red-600 text-white px-5 py-2 text-2xl font-bold uppercase animate-pulse shadow-md rounded-sm">● LIVE</div>
                         <div class="bg-black/60 text-white px-5 py-2 text-2xl font-bold uppercase backdrop-blur-md rounded-sm border border-white/10">${state.badge}</div>
                    </div>
                </div>
                <div class="h-[18%] w-full bg-blue-950 relative flex items-center px-12 border-t-8 border-yellow-400">
                     <div class="bg-yellow-400 text-blue-950 font-black text-4xl px-8 py-3 absolute -top-12 left-12 skew-x-[-20deg] shadow-[0_4px_10px_rgba(0,0,0,0.3)]">
                        <span class="skew-x-[20deg] inline-block">BREAKING</span>
                     </div>
                     <div class="w-full flex justify-between items-center text-white pt-2">
                        <h1 id="cardTitle" class="text-[45px] font-bold line-clamp-2 w-[75%] leading-snug">${state.title}</h1>
                        <div class="flex flex-col items-end border-l-2 pl-8 border-blue-700/50">
                             <span class="text-2xl font-bold text-yellow-400 uppercase tracking-wider" id="brandNameDisplay">${state.brand}</span>
                             <span class="text-xl opacity-80">${state.date}</span>
                        </div>
                     </div>
                </div>
            </div>`;
        }
    };

    // Include other previous templates if needed, mapped similarly...
    // Adding fallbacks for others to use Classic structure but slight mods if desired
    templates.glass_blur = templates.classic; 
    templates.neon_dark = templates.viral_bold;

    // --- LOGIC ---

    function toBanglaNum(str) {
        return str.toString().replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]);
    }

    function openGenerator(title, image, source) {
        modal.classList.remove('hidden');
        
        // Parse Title
        const parser = new DOMParser();
        const decodedTitle = parser.parseFromString(title, "text/html").documentElement.textContent;
        
        state.title = decodedTitle;
        state.badge = source;
        state.image = image ? proxyRoute + "?url=" + encodeURIComponent(image) : "";
        
        // Set Inputs
        document.getElementById('inputTitle').value = decodedTitle;
        document.getElementById('badgeTextInput').value = source;
        document.getElementById('logoInput').value = "";

        // Set Date
        const date = new Date();
        const day = toBanglaNum(date.getDate().toString().padStart(2, '0'));
        const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
        const year = toBanglaNum(date.getFullYear());
        state.date = `${day} ${months[date.getMonth()]}, ${year}`;

        // Init
        document.getElementById('templateSelector').value = 'viral_bold';
        changeTemplate('viral_bold');
    }

    function closeModal() { modal.classList.add('hidden'); }

    function render() {
        const container = document.getElementById('canvas-container');
        
        // Get Template Function
        const templateFunc = templates[currentTemplate] || templates['classic'];
        
        // Render HTML
        container.innerHTML = templateFunc();

        // Apply Images & Logic after Render
        const imgEl = document.getElementById('cardImage');
        const logoImg = document.getElementById('logoImg');
        const logoWrapper = document.getElementById('logoWrapper');
        const badgeEl = document.getElementById('textBadge');

        if(imgEl && state.image) imgEl.src = state.image;
        
        // Logo vs Badge Logic
        if(state.logo) {
            if(logoImg) logoImg.src = state.logo;
            if(logoWrapper) logoWrapper.classList.remove('hidden');
            if(badgeEl) badgeEl.style.display = 'none'; // hide badge if logo present
        } else {
            if(logoWrapper) logoWrapper.classList.add('hidden');
            if(badgeEl) badgeEl.style.display = 'block';
        }

        // Apply Font Size
        const titleEl = document.getElementById('cardTitle');
        const slider = document.querySelector('input[type=range]');
        if(titleEl && slider) titleEl.style.fontSize = slider.value + 'px';
        
        // Apply Alignment
        if(titleEl) {
             // Alignment state is handled by button clicks adding classes directly, 
             // but we can enforce defaults here if needed.
        }
    }

    // --- ACTIONS ---

    function changeTemplate(val) {
        currentTemplate = val;
        render();
    }

    function updateCard() {
        state.title = document.getElementById('inputTitle').value;
        const el = document.getElementById('cardTitle');
        if(el) el.innerText = state.title;
    }

    function updateBadgeText() {
        state.badge = document.getElementById('badgeTextInput').value;
        const el = document.getElementById('textBadge');
        if(el) el.innerText = state.badge;
        // If typing badge, remove logo
        state.logo = null;
        render();
    }

    function updateBrand() {
        state.brand = document.getElementById('brandInput').value;
        const el = document.getElementById('brandNameDisplay');
        if(el) el.innerText = state.brand;
    }

    function updateFontSize(val) {
        const el = document.getElementById('cardTitle');
        if(el) el.style.fontSize = val + "px";
    }

    function setTextAlign(align) {
        const el = document.getElementById('cardTitle');
        if(el) {
            el.classList.remove('text-left', 'text-center', 'text-right');
            el.classList.add('text-' + align);
        }
    }

    function setThemeColor(color) {
        state.themeColor = color;
        render(); // Re-render template to apply new color classes
    }

    function uploadLogo() {
        const file = document.getElementById('logoInput').files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                state.logo = e.target.result;
                render();
            }
            reader.readAsDataURL(file);
        }
    }

    function resetLogo() {
        document.getElementById('logoInput').value = "";
        state.logo = null;
        render();
    }

    // --- ZOOM & DOWNLOAD ---

    function changeZoom(delta) {
        state.zoom += delta;
        if(state.zoom < 0.2) state.zoom = 0.2;
        updatePreviewScale();
    }
    
    function resetZoom() {
        state.zoom = 0.55;
        updatePreviewScale();
    }

    function updatePreviewScale() {
        const wrapper = document.getElementById('preview-wrapper');
        wrapper.style.transform = `scale(${state.zoom})`;
    }

    // Initialize Zoom
    updatePreviewScale();

    function downloadCard() {
        const originalNode = document.getElementById("canvas-container");
        const btn = document.getElementById('downloadBtn');
        const originalText = btn.innerHTML;
       
        btn.innerHTML = "⏳ জেনারেট হচ্ছে...";
        btn.disabled = true;

        const clone = originalNode.cloneNode(true);
        clone.style.transform = "none";
        clone.style.position = "fixed";
        clone.style.top = "0";
        clone.style.left = "0";
        clone.style.zIndex = "-1"; // hide behind
        // Force full size
        clone.style.width = "1080px";
        clone.style.height = "1080px";
        
        document.body.appendChild(clone);
        
        // Wait for images
        setTimeout(() => {
            html2canvas(clone, {
                scale: 1, // 1080px default
                width: 1080, 
                height: 1080, 
                useCORS: true, 
                allowTaint: true,
                backgroundColor: null,
                logging: false
            }).then(canvas => {
                const link = document.createElement('a');
                link.download = `News_${Date.now()}.png`;
                link.href = canvas.toDataURL('image/png', 1.0);
                link.click();
                
                document.body.removeChild(clone);
                btn.innerHTML = originalText;
                btn.disabled = false;
            });
        }, 500);
    }
</script>
@endsection