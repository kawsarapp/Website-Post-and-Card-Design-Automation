@extends('layouts.app')

@section('content')
<style>
    @import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&display=swap');
    
    /* Custom Scrollbar for Studio */
    .custom-scrollbar::-webkit-scrollbar { width: 5px; }
    .custom-scrollbar::-webkit-scrollbar-track { background: #f8fafc; }
    .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    
    .font-bangla { font-family: 'Hind Siliguri', sans-serif; }
    
    /* Hide Header/Footer of main layout if possible or override */
    /* Assuming standard layout, we take full height */
</style>

<div class="fixed inset-0 bg-gray-100 z-50 flex flex-col">
    <!-- Studio Header -->
    <div class="bg-white border-b border-gray-200 px-6 py-3 flex justify-between items-center shadow-sm z-30">
        <div class="flex items-center gap-3">
            <a href="{{ route('news.index') }}" class="flex items-center gap-1 text-gray-500 hover:text-gray-800 transition font-bold text-sm bg-gray-100 px-3 py-1.5 rounded-lg">
                ← Back
            </a>
            <h1 class="text-xl font-bold text-gray-800 flex items-center gap-2">
                🎨 নিউজ স্টুডিও <span class="text-sm bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full font-normal">Pro</span>
            </h1>
        </div>
        <div>
             <button id="downloadBtn" onclick="downloadCard()" class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-lg font-bold text-sm hover:shadow-lg transition flex items-center gap-2">
                📥 ডাউনলোড ইমেজ
            </button>
        </div>
    </div>

    <div class="flex flex-1 overflow-hidden">
        
        <!-- SIDEBAR CONTROLS -->
        <div class="w-[350px] bg-white border-r border-gray-200 flex flex-col overflow-y-auto custom-scrollbar shadow-xl z-20">
            <div class="p-5 space-y-6">
                
                <!-- 1. Template Select -->
                <div class="space-y-2">
                    <label class="text-xs font-bold text-slate-500 uppercase tracking-wider">ডিজাইন টেমপ্লেট</label>
                    <div class="relative">
                        <select id="templateSelector" onchange="changeTemplate(this.value)" class="w-full pl-3 pr-10 py-3 bg-slate-50 border border-gray-200 rounded-lg text-sm font-bold text-gray-700 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer">
                            <optgroup label="✨ New Premium">
                                <option value="viral_bold">⚡ Viral Bold (Yellow/Black)</option>
                                <option value="quote_pro">❝ Quote Statement</option>
                                <option value="insta_modern">📸 Insta Modern (Square)</option>
                            </optgroup>
                            <optgroup label="📺 Standard">
                                <option value="classic">Classic Studio</option>
                                <option value="modern_split">Modern Split</option>
                                <option value="bold_overlay">Breaking Red</option>
                                <option value="broadcast_tv">TV Broadcast</option>
                                <option value="glass_blur">Glassmorphism</option>
                            </optgroup>
                        </select>
                    </div>
                </div>

                <!-- 2. Text Content -->
                <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                    <label class="text-xs font-bold text-slate-400 uppercase">হেডলাইন</label>
                    <textarea id="inputTitle" class="w-full bg-white border border-slate-200 p-3 rounded-lg text-base h-28 focus:ring-2 focus:ring-indigo-500 outline-none font-bangla font-bold text-slate-800 resize-none" oninput="updateCard()">{{ $newsItem->title }}</textarea>
                    
                    <div class="flex items-center gap-2 pt-2 border-t border-dashed border-gray-200">
                        <span class="text-xs text-slate-400">Size</span>
                        <input type="range" min="30" max="120" value="65" class="flex-1 accent-indigo-600" oninput="updateFontSize(this.value)">
                    </div>
                </div>

                <!-- 3. Branding -->
                <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                    <label class="text-xs font-bold text-slate-400 uppercase">ব্র্যান্ডিং</label>
                    <div class="flex gap-2">
                            <input type="text" id="badgeTextInput" value="{{ $newsItem->website->name }}" placeholder="Topic" class="w-1/2 bg-white border p-2 rounded-lg text-sm font-bold text-red-600" oninput="updateBadgeText()">
                            <input type="text" id="brandInput" value="News Studio" class="w-1/2 bg-white border p-2 rounded-lg text-sm font-bold text-slate-700" oninput="updateBrand()">
                    </div>
                    <div class="flex gap-2">
                        <label class="flex-1 cursor-pointer bg-white border border-indigo-100 text-indigo-600 px-3 py-2 rounded-lg text-xs font-bold hover:bg-indigo-50 text-center flex items-center justify-center gap-1 transition">
                            <input type="file" id="logoInput" accept="image/*" onchange="uploadLogo()" class="hidden">
                            📤 Logo
                        </label>
                        <button onclick="resetLogo()" class="bg-white text-red-500 border border-red-100 px-3 rounded-lg hover:bg-red-50">✕</button>
                    </div>
                </div>

                <!-- 4. Theme Colors -->
                <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                    <label class="text-xs font-bold text-slate-400 uppercase">কালার থিম</label>
                    <div class="flex justify-between gap-2">
                            <button onclick="setThemeColor('red')" class="w-8 h-8 rounded-full bg-red-600 ring-2 ring-offset-2 ring-transparent hover:ring-red-300"></button>
                            <button onclick="setThemeColor('blue')" class="w-8 h-8 rounded-full bg-blue-600 ring-2 ring-offset-2 ring-transparent hover:ring-blue-300"></button>
                            <button onclick="setThemeColor('emerald')" class="w-8 h-8 rounded-full bg-emerald-600 ring-2 ring-offset-2 ring-transparent hover:ring-emerald-300"></button>
                            <button onclick="setThemeColor('purple')" class="w-8 h-8 rounded-full bg-purple-600 ring-2 ring-offset-2 ring-transparent hover:ring-purple-300"></button>
                            <button onclick="setThemeColor('black')" class="w-8 h-8 rounded-full bg-black ring-2 ring-offset-2 ring-transparent hover:ring-gray-300"></button>
                    </div>
                </div>
            </div>
        </div>

        <!-- MAIN CANVAS PREVIEW -->
        <div class="flex-1 bg-gray-200 flex items-center justify-center overflow-auto relative p-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
             <!-- Zoom Controls -->
             <div class="absolute bottom-6 right-6 flex bg-white shadow-lg rounded-full px-4 py-2 gap-4 z-40">
                <button onclick="changeZoom(-0.1)" class="font-bold text-gray-600 hover:text-indigo-600 text-xl">-</button>
                <span class="text-sm font-bold text-gray-400 pt-1">ZOOM</span>
                <button onclick="changeZoom(0.1)" class="font-bold text-gray-600 hover:text-indigo-600 text-xl">+</button>
            </div>

            <div id="preview-wrapper" class="shadow-2xl transition-transform duration-200 ease-out origin-center ring-8 ring-white">
                <div id="canvas-container" class="bg-white relative flex flex-col overflow-hidden"
                        style="width: 1080px; height: 1080px; flex-shrink: 0;">
                        <!-- JS WILL INJECT HTML HERE -->
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
    // --- INITIAL DATA FROM LARAVEL ---
    const newsData = {
        title: {!! json_encode($newsItem->title) !!},
        source: {!! json_encode($newsItem->website->name) !!},
        image: "{{ $newsItem->thumbnail_url ? route('proxy.image', ['url' => $newsItem->thumbnail_url]) : '' }}"
    };

    // --- STATE ---
    let state = {
        title: newsData.title,
        image: newsData.image,
        badge: newsData.source,
        brand: "News Studio",
        date: "",
        logo: null,
        themeColor: 'red',
        zoom: 0.5
    };
    
    let currentTemplate = 'viral_bold';

    // --- TEMPLATE HELPERS ---
    const getThemeClass = () => {
        const colors = {
            red: { bg: 'bg-red-600', text: 'text-red-600', border: 'border-red-600' },
            blue: { bg: 'bg-blue-600', text: 'text-blue-600', border: 'border-blue-600' },
            emerald: { bg: 'bg-emerald-600', text: 'text-emerald-600', border: 'border-emerald-600' },
            purple: { bg: 'bg-purple-700', text: 'text-purple-700', border: 'border-purple-700' },
            black: { bg: 'bg-black', text: 'text-black', border: 'border-black' }
        };
        return colors[state.themeColor] || colors['red'];
    }

    // --- TEMPLATES DEFINITIONS ---
    const templates = {
        viral_bold: () => {
            const c = getThemeClass();
            return `
            <div class="w-full h-full bg-[#111] flex flex-col relative font-bangla">
                <div class="h-[65%] w-full relative overflow-hidden group">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover opacity-90">
                    <div class="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#111]"></div>
                    <div class="absolute top-10 left-10">
                        <div class="${c.bg} text-white px-6 py-2 text-2xl font-black italic uppercase tracking-wider transform -skew-x-12 inline-block shadow-[4px_4px_0px_0px_rgba(255,255,255,0.2)]" id="textBadge">
                            ${state.badge}
                        </div>
                    </div>
                </div>
                <div class="h-[35%] w-full p-12 flex flex-col justify-start relative z-10">
                     <div class="w-24 h-2 ${c.bg} mb-6"></div>
                     <h1 id="cardTitle" class="text-[65px] font-bold text-white leading-[1.15] mb-4 drop-shadow-xl text-left">
                        ${state.title}
                     </h1>
                     <div class="mt-auto pt-6 border-t border-gray-800 flex justify-between items-center text-gray-400">
                        <div class="flex items-center gap-3">
                            <div id="logoWrapper" class="hidden"><img id="logoImg" src="" class="h-12 w-auto"></div>
                            <span class="text-2xl font-bold uppercase tracking-widest text-white" id="brandNameDisplay">${state.brand}</span>
                        </div>
                        <span class="text-2xl font-mono">${state.date}</span>
                     </div>
                </div>
            </div>`;
        },
        quote_pro: () => {
             const c = getThemeClass();
             return `
             <div class="w-full h-full bg-slate-50 border-[20px] border-white relative font-bangla flex flex-col">
                <div class="h-[55%] relative overflow-hidden m-4 rounded-3xl">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover grayscale-[20%]">
                    <div class="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-transparent to-transparent"></div>
                    <div class="absolute bottom-8 left-8 text-white/80 font-bold text-xl uppercase tracking-[0.2em] border-l-4 ${c.border} pl-4">
                        ${state.badge}
                    </div>
                </div>
                <div class="h-[45%] px-16 py-8 flex flex-col justify-center relative">
                    <div class="absolute -top-10 right-16 text-[180px] leading-none ${c.text} opacity-20 font-serif">”</div>
                    <h1 id="cardTitle" class="text-[55px] font-bold text-slate-800 leading-tight z-10 text-center italic">
                        ${state.title}
                    </h1>
                    <div class="w-full flex justify-center mt-10">
                        <div class="px-8 py-3 bg-white border border-slate-200 rounded-full shadow-sm flex items-center gap-4">
                             <div id="logoWrapper" class="hidden"><img id="logoImg" src="" class="h-8 w-auto"></div>
                             <span class="text-xl font-bold ${c.text} uppercase" id="brandNameDisplay">${state.brand}</span>
                             <span class="w-1 h-6 bg-gray-200"></span>
                             <span class="text-lg text-gray-500 font-bold">${state.date}</span>
                        </div>
                    </div>
                </div>
             </div>`;
        },
        insta_modern: () => {
             const c = getThemeClass();
             return `
             <div class="w-full h-full bg-white relative font-bangla p-10 flex flex-col items-center justify-center">
                <div class="w-full h-full border border-gray-100 rounded-[50px] shadow-2xl overflow-hidden relative bg-gray-900">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover opacity-60">
                    <div class="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/10"></div>
                    <div class="absolute top-0 w-full p-10 flex justify-between items-center">
                        <div class="flex items-center gap-3 bg-white/10 backdrop-blur px-5 py-2 rounded-full border border-white/10">
                             <div class="w-3 h-3 ${c.bg} rounded-full animate-pulse"></div>
                             <span class="text-white font-bold text-xl uppercase tracking-wider">${state.badge}</span>
                        </div>
                        <div id="logoWrapper" class="hidden"><img id="logoImg" src="" class="h-14 w-auto drop-shadow-lg"></div>
                    </div>
                    <div class="absolute bottom-0 w-full p-12 pb-16">
                        <h1 id="cardTitle" class="text-[60px] font-bold text-white leading-tight mb-8 drop-shadow-lg border-l-8 ${c.border} pl-8">
                            ${state.title}
                        </h1>
                        <div class="flex items-center gap-4 text-gray-300 ml-8">
                             <span class="font-bold text-2xl text-white" id="brandNameDisplay">${state.brand}</span>
                             <span>•</span>
                             <span class="text-xl">${state.date}</span>
                        </div>
                    </div>
                </div>
             </div>`;
        },
        classic: () => {
            const c = getThemeClass();
            return `
            <div class="flex flex-col h-full bg-white font-bangla">
                <div class="h-[60%] relative overflow-hidden">
                     <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover">
                     <div class="absolute bottom-0 left-0 w-full h-1/3 bg-gradient-to-t from-black/50 to-transparent"></div>
                     <div class="absolute top-8 left-8 ${c.bg} text-white px-6 py-2 text-3xl font-bold uppercase shadow-lg">${state.badge}</div>
                </div>
                <div class="h-[40%] px-12 flex flex-col justify-center items-center text-center bg-white text-slate-900 relative">
                     <div class="w-20 h-2 ${c.bg} mb-6 rounded-full"></div>
                     <h1 id="cardTitle" class="text-[55px] font-bold leading-snug line-clamp-4">${state.title}</h1>
                     <div class="absolute bottom-6 w-full px-12 flex justify-between border-t border-gray-100 pt-4 text-gray-500">
                        <span class="text-2xl font-bold uppercase ${c.text}" id="brandNameDisplay">${state.brand}</span>
                        <span class="text-2xl font-semibold">${state.date}</span>
                     </div>
                </div>
            </div>`;
        },
        modern_split: () => {
             const c = getThemeClass();
             return `
             <div class="flex h-full w-full bg-white relative font-bangla">
                <div class="w-1/2 h-full relative overflow-hidden">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover">
                    <div class="absolute inset-0 bg-black/10"></div>
                </div>
                <div class="w-1/2 h-full p-16 flex flex-col justify-center bg-slate-50 relative">
                    <div class="absolute top-0 right-0 w-32 h-32 ${c.bg} opacity-10 rounded-bl-[100px]"></div>
                    <div class="w-full mb-8">
                        <span class="${c.text} border ${c.border} px-4 py-1 text-xl font-bold uppercase tracking-widest rounded bg-white" id="textBadge">${state.badge}</span>
                    </div>
                    <h1 id="cardTitle" class="text-[60px] font-extrabold text-slate-900 leading-[1.2] mb-10 text-left">
                        ${state.title}
                    </h1>
                    <div class="mt-auto border-t-2 border-slate-200 pt-8 flex justify-between items-center text-slate-500">
                         <div class="flex items-center gap-2">
                             <div id="logoWrapper" class="hidden"><img id="logoImg" src="" class="h-12 w-auto"></div>
                             <span class="text-2xl font-bold uppercase text-slate-800 tracking-wider" id="brandNameDisplay">${state.brand}</span>
                         </div>
                         <span class="text-2xl font-medium">${state.date}</span>
                    </div>
                </div>
            </div>`;
        },
        bold_overlay: () => {
             const c = getThemeClass();
             return `
             <div class="relative h-full w-full overflow-hidden bg-black font-bangla">
                <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover opacity-70">
                <div class="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                <div class="absolute top-0 w-full h-4 ${c.bg}"></div>
                <div class="absolute bottom-0 w-full p-20 flex flex-col items-start justify-end h-full">
                    <div class="${c.bg} text-white font-bold px-6 py-2 text-2xl mb-6 uppercase tracking-widest inline-block skew-x-[-10deg] shadow-lg">
                        <span class="skew-x-[10deg] inline-block">${state.badge}</span>
                    </div>
                    <h1 id="cardTitle" class="text-[80px] font-black text-white leading-tight drop-shadow-2xl text-left border-l-[12px] ${c.border} pl-10">
                        ${state.title}
                    </h1>
                    <div class="w-full flex justify-between items-center mt-12 text-gray-300 border-t border-white/20 pt-8">
                        <span class="text-4xl font-bold text-white tracking-widest uppercase" id="brandNameDisplay">${state.brand}</span>
                        <span class="text-3xl font-light">${state.date}</span>
                    </div>
                </div>
            </div>`;
        },
        broadcast_tv: () => {
             const c = getThemeClass();
             return `
            <div class="relative h-full w-full bg-gray-900 overflow-hidden font-bangla">
                <div class="h-[82%] w-full relative">
                    <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover">
                     <div class="absolute top-10 left-10 flex items-center gap-4">
                         <div class="bg-red-600 text-white px-5 py-2 text-2xl font-bold uppercase animate-pulse shadow-md rounded-sm">● LIVE</div>
                         <div class="bg-black/60 text-white px-5 py-2 text-2xl font-bold uppercase backdrop-blur-md rounded-sm border border-white/10">${state.badge}</div>
                    </div>
                </div>
                <div class="h-[18%] w-full bg-blue-950 relative flex items-center px-12 border-t-8 border-yellow-400">
                     <div class="bg-yellow-400 text-blue-950 font-black text-4xl px-8 py-3 absolute -top-12 left-12 skew-x-[-20deg] shadow-[0_4px_10px_rgba(0,0,0,0.3)]">
                        <span class="skew-x-[20deg] inline-block">BREAKING</span>
                     </div>
                     <div class="w-full flex justify-between items-center text-white pt-2">
                        <h1 id="cardTitle" class="text-[45px] font-bold line-clamp-2 w-[75%] leading-snug">${state.title}</h1>
                        <div class="flex flex-col items-end border-l-2 pl-8 border-blue-700/50">
                             <span class="text-2xl font-bold text-yellow-400 uppercase tracking-wider" id="brandNameDisplay">${state.brand}</span>
                             <span class="text-xl opacity-80">${state.date}</span>
                        </div>
                     </div>
                </div>
            </div>`;
        },
        glass_blur: () => {
             // Reusing classic structure but with blur effect styles if needed, 
             // here just mapping to classic for simplicity as per previous request fallback
             // or implementing a basic glass overlay
             const c = getThemeClass();
             return `
            <div class="relative h-full w-full overflow-hidden bg-gray-800 flex items-center justify-center font-bangla">
                <img id="cardImage" src="" class="absolute inset-0 w-full h-full object-cover scale-110 filter blur-sm brightness-75">
                <div class="relative w-[90%] bg-white/10 backdrop-blur-xl border border-white/20 p-12 rounded-3xl shadow-2xl flex flex-col items-center text-center">
                    <div class="absolute -top-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-full text-2xl font-bold shadow-lg uppercase" id="textBadge">
                        ${state.badge}
                    </div>
                     <div id="logoWrapper" class="hidden absolute -top-10"><img id="logoImg" src="" class="h-24 w-auto drop-shadow-lg bg-white rounded-full p-2"></div>
                    <div class="mt-8 mb-6 w-20 h-1 bg-white/50 rounded-full"></div>
                    <h1 id="cardTitle" class="text-[60px] font-bold text-white leading-tight drop-shadow-md mb-8">
                        ${state.title}
                    </h1>
                    <div class="w-full border-t border-white/20 pt-6 flex justify-between items-center text-white/90">
                        <span class="text-2xl font-bold tracking-widest uppercase" id="brandNameDisplay">${state.brand}</span>
                        <span class="text-2xl">${state.date}</span>
                    </div>
                </div>
            </div>`;
        }
    };

    // --- MAIN FUNCTIONS ---
    function toBanglaNum(str) {
        return str.toString().replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[d]);
    }

    function init() {
        const date = new Date();
        const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
        const day = toBanglaNum(date.getDate().toString().padStart(2, '0'));
        const year = toBanglaNum(date.getFullYear());
        state.date = `${day} ${months[date.getMonth()]}, ${year}`;
        
        render();
        updatePreviewScale();
    }

    function render() {
        const container = document.getElementById('canvas-container');
        const templateFunc = templates[currentTemplate] || templates['classic'];
        
        container.innerHTML = templateFunc();

        // Bind Data
        const imgEl = document.getElementById('cardImage');
        const logoImg = document.getElementById('logoImg');
        const logoWrapper = document.getElementById('logoWrapper');
        const badgeEl = document.getElementById('textBadge');

        if(imgEl && state.image) imgEl.src = state.image;
        
        // Logo vs Badge
        if(state.logo) {
            if(logoImg) logoImg.src = state.logo;
            if(logoWrapper) logoWrapper.classList.remove('hidden');
            if(badgeEl) badgeEl.style.display = 'none';
        } else {
            if(logoWrapper) logoWrapper.classList.add('hidden');
            if(badgeEl) badgeEl.style.display = 'block';
        }

        // Font Size
        const titleEl = document.getElementById('cardTitle');
        const slider = document.querySelector('input[type=range]');
        if(titleEl && slider) titleEl.style.fontSize = slider.value + 'px';
    }

    // --- EVENT HANDLERS ---
    function changeTemplate(val) {
        currentTemplate = val;
        render();
    }
    function updateCard() {
        state.title = document.getElementById('inputTitle').value;
        const el = document.getElementById('cardTitle');
        if(el) el.innerText = state.title;
    }
    function updateBadgeText() {
        state.badge = document.getElementById('badgeTextInput').value;
        const el = document.getElementById('textBadge');
        if(el) el.innerText = state.badge;
        state.logo = null;
        render();
    }
    function updateBrand() {
        state.brand = document.getElementById('brandInput').value;
        const el = document.getElementById('brandNameDisplay');
        if(el) el.innerText = state.brand;
    }
    function updateFontSize(val) {
        const el = document.getElementById('cardTitle');
        if(el) el.style.fontSize = val + "px";
    }
    function setThemeColor(color) {
        state.themeColor = color;
        render();
    }
    function uploadLogo() {
        const file = document.getElementById('logoInput').files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                state.logo = e.target.result;
                render();
            }
            reader.readAsDataURL(file);
        }
    }
    function resetLogo() {
        document.getElementById('logoInput').value = "";
        state.logo = null;
        render();
    }
    function changeZoom(delta) {
        state.zoom += delta;
        if(state.zoom < 0.2) state.zoom = 0.2;
        updatePreviewScale();
    }
    function updatePreviewScale() {
        document.getElementById('preview-wrapper').style.transform = `scale(${state.zoom})`;
    }

    function downloadCard() {
        const originalNode = document.getElementById("canvas-container");
        const btn = document.getElementById('downloadBtn');
        const originalText = btn.innerHTML;
        btn.innerHTML = "⏳ জেনারেট হচ্ছে...";
        btn.disabled = true;

        const clone = originalNode.cloneNode(true);
        clone.style.transform = "none";
        clone.style.position = "fixed";
        clone.style.top = "0";
        clone.style.left = "0";
        clone.style.zIndex = "-1";
        clone.style.width = "1080px";
        clone.style.height = "1080px";
        document.body.appendChild(clone);
        
        setTimeout(() => {
            html2canvas(clone, { scale: 1, width: 1080, height: 1080, useCORS: true, allowTaint: true, backgroundColor: null })
            .then(canvas => {
                const link = document.createElement('a');
                link.download = `News_${Date.now()}.png`;
                link.href = canvas.toDataURL('image/png', 1.0);
                link.click();
                document.body.removeChild(clone);
                btn.innerHTML = originalText;
                btn.disabled = false;
            });
        }, 500);
    }

    // Start
    init();
</script>
@endsection