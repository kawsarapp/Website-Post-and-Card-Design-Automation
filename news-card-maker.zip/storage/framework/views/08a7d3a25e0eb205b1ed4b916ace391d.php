

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    
    <div class="bg-white p-6 rounded-lg shadow-md h-fit">
        <h2 class="text-xl font-bold mb-4 border-b pb-2">Add New Website</h2>
        
        <form action="<?php echo e(route('websites.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Website Name</label>
                <input type="text" name="name" placeholder="e.g. Dhaka Post" class="w-full border p-2 rounded mt-1" required>
            </div>

            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Website URL</label>
                <input type="url" name="url" placeholder="https://www.dhakapost.com" class="w-full border p-2 rounded mt-1" required>
            </div>

            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Main Container (CSS Class)</label>
                <input type="text" name="selector_container" placeholder="e.g. .news-item or .card" class="w-full border p-2 rounded mt-1" required>
                <p class="text-xs text-gray-500 mt-1">যে বক্সের ভেতরে পুরো নিউজটা আছে।</p>
            </div>

            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Title Selector</label>
                <input type="text" name="selector_title" placeholder="e.g. h2 or .title" class="w-full border p-2 rounded mt-1" required>
            </div>

            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700">Image Selector (Optional)</label>
                <input type="text" name="selector_image" placeholder="e.g. img" class="w-full border p-2 rounded mt-1">
            </div>

            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition">
                Save Website
            </button>
        </form>
    </div>

    <div class="col-span-2 bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-bold mb-4 border-b pb-2">Connected Websites</h2>
        
        <table class="w-full border-collapse">
            <thead>
                <tr class="bg-gray-100 text-left">
                    <th class="p-3 border">Name</th>
                    <th class="p-3 border">URL</th>
                    <th class="p-3 border">Selectors</th>
                    <th class="p-3 border text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="p-3 font-semibold"><?php echo e($website->name); ?></td>
                    <td class="p-3 text-blue-500 text-sm truncate max-w-xs">
                        <a href="<?php echo e($website->url); ?>" target="_blank"><?php echo e($website->url); ?></a>
                    </td>
                    <td class="p-3 text-xs text-gray-600">
                        <span class="bg-gray-200 px-1 rounded">Box: <?php echo e($website->selector_container); ?></span>
                        <span class="bg-gray-200 px-1 rounded">Title: <?php echo e($website->selector_title); ?></span>
                    </td>
                    <td class="p-3 text-center">
                        <a href="<?php echo e(route('websites.scrape', $website->id)); ?>" 
                           class="bg-green-500 text-white px-4 py-2 rounded text-sm hover:bg-green-600 flex items-center justify-center gap-2">
                           🔄 Fetch News
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($websites->isEmpty()): ?>
                <tr>
                    <td colspan="4" class="p-4 text-center text-gray-500">No websites added yet.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\laragon\www\news-card-maker\resources\views/websites/index.blade.php ENDPATH**/ ?>