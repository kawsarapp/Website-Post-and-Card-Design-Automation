<?php

namespace App\Http\Controllers;

use App\Models\Website;
use App\Models\NewsItem;
use Illuminate\Http\Request;
use Symfony\Component\DomCrawler\Crawler;
use Illuminate\Support\Facades\Log;

class WebsiteController extends Controller
{
    public function index()
    {
        $websites = Website::all();
        return view('websites.index', compact('websites'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'url' => 'required|url',
            'selector_container' => 'required',
            'selector_title' => 'required',
        ]);

        Website::create($request->all());

        return back()->with('success', 'Website added successfully!');
    }

    public function scrape($id)
    {
        // ✅ ১. হিউম্যান ডিলে (Human Delay): 
        // বাটন চাপার সাথে সাথে রিকোয়েস্ট গেলে রোবট মনে হতে পারে। 
        // তাই ৩ থেকে ৮ সেকেন্ড র‍্যান্ডম অপেক্ষা করবে।
        sleep(rand(3, 8));

        $website = Website::findOrFail($id);
        
        // ফাইলের নাম ইউনিক করা
        $fileName = "scrape_" . time() . "_{$website->id}.html";
        $tempFile = storage_path("app/public/{$fileName}");
        $scriptPath = base_path("scraper-engine.js");

        // ✅ JS আপডেট: ক্যানভাস নয়েজ + WebGL স্পুফিং + র‍্যান্ডম হার্ডওয়্যার কনফিগ + মাউস জিটার
        $jsCode = <<<'JS'
import puppeteer from 'puppeteer';
import fs from 'fs';

const url = process.argv[2];
const outputFile = process.argv[3];

if (!url || !outputFile) process.exit(1);

const userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
];

(async () => {
  const browser = await puppeteer.launch({
    headless: "new",
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-blink-features=AutomationControlled',
      '--window-size=1920,1080',
      '--disable-infobars',
      '--exclude-switches=enable-automation'
    ]
  });

  try {
    const page = await browser.newPage();
    
    // ১. র‍্যান্ডম ইউজার এজেন্ট
    const randomUA = userAgents[Math.floor(Math.random() * userAgents.length)];
    await page.setUserAgent(randomUA);

    // ২. র‍্যান্ডম ভিউপোর্ট (মনিটর সাইজ সিমুলেশন)
    const width = 1366 + Math.floor(Math.random() * 500); 
    const height = 768 + Math.floor(Math.random() * 300);
    await page.setViewport({ width, height });

    // ৩. আল্টিমেট ইভেশন (Detection Bypass - 100% Safe)
    await page.evaluateOnNewDocument(() => {
        // Webdriver লুকানো
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        
        // হার্ডওয়্যার মক করা (সার্ভার পিসি না মনে হওয়ার জন্য)
        Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 4 + Math.floor(Math.random() * 4) });
        Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });

        // ল্যাঙ্গুয়েজ ও প্লাগিনস
        Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en', 'bn'] });
        Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });

        // ✅ Canvas Fingerprinting Spoofing (সবচেয়ে গুরুত্বপূর্ণ - Cloudflare Bypass)
        const toBlob = HTMLCanvasElement.prototype.toBlob;
        const toDataURL = HTMLCanvasElement.prototype.toDataURL;
        const getImageData = CanvasRenderingContext2D.prototype.getImageData;
        
        // ক্যানভাসে সামান্য র‍্যান্ডম নয়েজ যোগ করা
        var noise = {
            r: Math.floor(Math.random() * 10) - 5,
            g: Math.floor(Math.random() * 10) - 5,
            b: Math.floor(Math.random() * 10) - 5
        };

        CanvasRenderingContext2D.prototype.getImageData = function() {
            const imageData = getImageData.apply(this, arguments);
            // পিক্সেল ডেটায় সামান্য পরিবর্তন আনা
            for (let i = 0; i < imageData.data.length; i += 4) {
                imageData.data[i] = imageData.data[i] + noise.r;
                imageData.data[i+1] = imageData.data[i+1] + noise.g;
                imageData.data[i+2] = imageData.data[i+2] + noise.b;
            }
            return imageData;
        };
    });

    // ৪. হেডার অপটিমাইজেশন
    await page.setExtraHTTPHeaders({
        'Accept-Language': 'en-US,en;q=0.9,bn;q=0.8',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
    });

    // ৫. রিসোর্স ব্লক (ব্যান্ডউইথ সেইভ করার জন্য ইমেজ ডাউনলোড বন্ধ, কিন্তু ট্যাগ থাকবে)
    await page.setRequestInterception(true);
    page.on('request', (req) => {
        const resourceType = req.resourceType();
        if (['image', 'media', 'font', 'stylesheet'].includes(resourceType)) {
            req.abort();
        } else {
            req.continue();
        }
    });

    // নেভিগেশন
    try {
        await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });
    } catch (error) {
        console.log("Nav timeout, checking content...");
    }

    // ৬. হিউম্যান বিহেভিয়ার (মাউস জিটার - Mouse Jitter)
    const steps = 15;
    for(let i=0; i<steps; i++){
        await page.mouse.move(
            Math.floor(Math.random() * width),
            Math.floor(Math.random() * height),
            { steps: 5 }
        );
    }

    // ৭. স্মার্ট র‍্যান্ডম স্ক্রলিং (ন্যাচারাল স্ক্রল)
    await page.evaluate(async () => {
        await new Promise((resolve) => {
            let totalHeight = 0;
            const timer = setInterval(() => {
                const scrollHeight = document.body.scrollHeight;
                const randomScroll = Math.floor(Math.random() * 200) + 200; 
                window.scrollBy(0, randomScroll);
                totalHeight += randomScroll;
                
                // স্ক্রল থামানোর শর্ত (খুব বেশি নিচে নামবে না)
                if (totalHeight >= scrollHeight || totalHeight > 8000) {
                    clearInterval(timer);
                    resolve();
                }
            }, 300 + Math.floor(Math.random() * 200)); 
        });
    });

    // ৮. ইমেজ হাইড্রেশন (লুকানো ইমেজ বের করা)
    await page.evaluate(() => {
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            const hiddenSrc = img.getAttribute('data-original') || img.getAttribute('data-src') || img.getAttribute('data-srcset');
            if (hiddenSrc) img.setAttribute('src', hiddenSrc);
        });
    });
    
    // র‍্যান্ডম ডিলে (২-৩ সেকেন্ড বিশ্রাম)
    const randomDelay = Math.floor(Math.random() * 2000) + 1500;
    await new Promise(r => setTimeout(r, randomDelay));

    const html = await page.content();
    fs.writeFileSync(outputFile, html);
    
    await browser.close();
    process.exit(0);

  } catch (error) {
    console.error('Puppeteer Error:', error);
    await browser.close();
    process.exit(1);
  }
})();
JS;

        file_put_contents($scriptPath, $jsCode);

        try {
            $command = "node \"$scriptPath\" \"{$website->url}\" \"$tempFile\" \"{$website->selector_container}\" 2>&1";
            shell_exec($command);

            if (!file_exists($tempFile)) {
                return back()->with('error', "স্ক্র্যাপার ফাইল তৈরি হয়নি।");
            }

            $html = file_get_contents($tempFile);
            unlink($tempFile); // ক্লিনআপ

            $crawler = new Crawler($html);
            
            // Cloudflare ব্লক চেক
            if (str_contains($html, 'Cloudflare') || str_contains($html, 'Attention Required')) {
                return back()->with('error', "Cloudflare ব্লক ডিটেক্টেড। আবার চেষ্টা করুন।");
            }

            $containers = $crawler->filter($website->selector_container);

            if ($containers->count() === 0) {
                return back()->with('error', "সিলেক্টর মিলেনি! ক্লাস নেম চেক করুন।");
            }

            $baseTime = now(); 
            $count = 0;
            
            // ✅ ৯. র‍্যান্ডম লিমিট সেট (৫ থেকে ১০টি নিউজ)
            // এটি হুবহু মানুষের মতো আচরণ করবে।
            $limit = rand(5, 10);

            $containers->each(function (Crawler $node) use ($website, &$count, $baseTime, $limit) {
                
                // লিমিট চেক: র‍্যান্ডম লিমিট পার হলে লুপ বন্ধ
                if ($count >= $limit) return false;

                try {
                    $titleNode = $node->filter($website->selector_title);
                    if ($titleNode->count() === 0) return;
                    $title = trim($titleNode->text());

                    $link = null;
                    $anchor = $node->filter('a');
                    if ($anchor->count() > 0) $link = $anchor->first()->attr('href');
                    else {
                        $titleLink = $node->filter($website->selector_title)->filter('a');
                        if ($titleLink->count() > 0) $link = $titleLink->attr('href');
                    }
                    if (!$link) return;

                    if (!str_starts_with($link, 'http')) {
                        $parsedUrl = parse_url($website->url);
                        $baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
                        $link = $baseUrl . '/' . ltrim($link, '/');
                    }

                    $image = null;
                    // ইমেজ খোঁজা: সিলেক্টর দিয়ে
                    if ($website->selector_image) {
                        try {
                            $targetNode = $node->filter($website->selector_image);
                            $image = $this->extractImageSrc($targetNode);
                        } catch (\Exception $e) {}
                    }
                    // ইমেজ খোঁজা: ফলব্যাক (যদি সিলেক্টরে না পায়)
                    if (!$image) {
                        try {
                            $fallbackImg = $node->filter('img');
                            if ($fallbackImg->count() > 0) {
                                $image = $this->extractImageSrc($fallbackImg->first());
                            }
                        } catch (\Exception $e) {}
                    }
                    // ইমেজ লিংক ফিক্স
                    if ($image) {
                        if (str_contains($image, ',')) $image = trim(explode(',', $image)[0]);
                        if (str_contains($image, ' ')) $image = trim(explode(' ', $image)[0]);
                        if (str_starts_with($image, '//')) $image = 'https:' . $image;
                        elseif (!str_starts_with($image, 'http')) {
                            $parsedUrl = parse_url($website->url);
                            $baseUrl = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
                            $image = $baseUrl . '/' . ltrim($image, '/');
                        }
                    }

                    // ডাটাবেস সেভ
                    NewsItem::updateOrCreate(
                        ['original_link' => $link],
                        [
                            'website_id' => $website->id,
                            'title' => $title,
                            'thumbnail_url' => $image,
                            'published_at' => $baseTime->copy()->subSeconds($count), 
                        ]
                    );
                    $count++;

                } catch (\Exception $e) {}
            });

            if ($count === 0) return back()->with('error', "কোনো নিউজ পাওয়া যায়নি।");
            
            // সাকসেস মেসেজ
            return back()->with('success', "✅ {$count}টি নিউজ স্ক্র্যাপ হয়েছে! (Stealth Mode: {$limit} Limit)");

        } catch (\Exception $e) {
            return back()->with('error', 'System Error: ' . $e->getMessage());
        }
    }
    
    // ইমেজ হেল্পার ফাংশন
    private function extractImageSrc($node)
    {
        if ($node->count() === 0) return null;
        $imgTag = ($node->nodeName() === 'img') ? $node : $node->filter('img');
        if ($imgTag->count() > 0) {
            $src = $imgTag->attr('src');
            if ($src && !str_contains($src, 'base64') && strlen($src) > 10) return $src;
            $attrs = ['data-original', 'data-src', 'srcset'];
            foreach ($attrs as $attr) {
                $val = $imgTag->attr($attr);
                if ($val && !str_contains($val, 'base64')) return $val;
            }
        } else {
            $style = $node->attr('style');
            if ($style && preg_match('/url\((.*?)\)/', $style, $matches)) return trim($matches[1], "'\" ");
        }
        return null;
    }
}