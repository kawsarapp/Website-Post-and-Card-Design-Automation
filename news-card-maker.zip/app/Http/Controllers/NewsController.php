<?php

namespace App\Http\Controllers;

use App\Models\NewsItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Symfony\Component\DomCrawler\Crawler;

class NewsController extends Controller
{
    // ওয়ার্ডপ্রেস ক্যাটাগরি আইডি (আপনার সেট করা)
    private $wpCategories = [
        'Politics'      => 14,
        'International' => 37,
        'Sports'        => 15,
        'Entertainment' => 11,
        'Technology'    => 1,
        'Economy'       => 1,
        'Bangladesh'    => 14,
        'Crime'         => 1,
        'Others'        => 1
    ];

    public function index()
    {
        $newsItems = NewsItem::with('website')
            ->orderBy('published_at', 'desc') 
            ->paginate(20);
            
        return view('news.index', compact('newsItems'));
    }

    // ✅ নতুন ফাংশন: স্টুডিও পেজ ওপেন করার জন্য
    public function studio($id)
    {
        $newsItem = NewsItem::with('website')->findOrFail($id);
        return view('news.studio', compact('newsItem'));
    }

    public function proxyImage(Request $request)
    {
        $url = $request->query('url');
        if (!$url) abort(404);
        try {
            $response = Http::withHeaders([
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
            ])->timeout(10)->get($url);
            
            if ($response->failed()) abort(404);
            return response($response->body())->header('Content-Type', $response->header('Content-Type'));
        } catch (\Exception $e) {
            abort(404);
        }
    }

    private function cleanUtf8($string) {
        if (is_string($string)) {
            return iconv('UTF-8', 'UTF-8//IGNORE', $string);
        }
        return $string;
    }

    public function postToWordPress($id)
    {
        set_time_limit(300); 

        $news = NewsItem::with('website')->findOrFail($id);

        if ($news->is_posted) {
            return back()->with('error', 'এই নিউজটি ইতিমধ্যে পোস্ট করা হয়েছে!');
        }

        $processLog = [];

        try {
            // ১. কন্টেন্ট ফেচ
            if (empty($news->content) || strlen($news->content) < 50) {
                $fullContent = $this->fetchFullContent($news->original_link, false);
                
                if (!$fullContent) {
                    $processLog[] = "⚠️ PHP ফেইল, Stealth Puppeteer ব্যবহার করা হচ্ছে...";
                    $fullContent = $this->fetchFullContent($news->original_link, true);
                }

                if ($fullContent) {
                    $news->update(['content' => $this->cleanUtf8($fullContent)]);
                    $processLog[] = "✅ কন্টেন্ট স্ক্র্যাপ সফল";
                } else {
                    $processLog[] = "❌ কন্টেন্ট স্ক্র্যাপ ব্যর্থ";
                    return back()->with('error', 'ডিটেইলস কন্টেন্ট পাওয়া যায়নি।');
                }
            }

            // ২. রিরাইট ও ক্যাটাগরি
            $rawText = $news->title . "\n\n" . strip_tags($news->content);
            $cleanText = $this->cleanUtf8($rawText);
            
            $aiResponse = $this->rewriteWithDeepSeek($cleanText);
            
            if (!$aiResponse) {
                return back()->with('error', 'DeepSeek রেসপন্স দেয়নি।');
            }

            $rewrittenContent = $aiResponse['content'];
            $detectedCategory = $aiResponse['category'];
            
            $categoryId = $this->wpCategories[$detectedCategory] ?? $this->wpCategories['Others'];

            $processLog[] = "✅ DeepSeek রিরাইট সফল";
            $processLog[] = "📂 ক্যাটাগরি: {$detectedCategory} (ID: {$categoryId})";

            // ৩. ইমেজ হ্যান্ডলিং
            $imageId = null;
            $imageStatus = "No Image";

            if ($news->thumbnail_url) {
                $uploadResult = $this->uploadImageToWP($news->thumbnail_url, $news->title);
                
                if ($uploadResult['success']) {
                    $imageId = $uploadResult['id'];
                    $imageStatus = "✅ ইমেজ আপলোড সফল (Media ID: $imageId)";
                } else {
                    $imageStatus = "⚠️ আপলোড ব্যর্থ (" . $uploadResult['error'] . ")";
                    $rewrittenContent = '<img src="' . $news->thumbnail_url . '" alt="' . $this->cleanUtf8($news->title) . '" style="width:100%; height:auto; margin-bottom:20px;"><br>' . $rewrittenContent;
                }
            }
            $processLog[] = $imageStatus;

            // ৪. পোস্ট পাবলিশ
            $wpBaseUrl = rtrim(env('WP_SITE_URL'), '/');

            $postData = [
                'title'   => $this->cleanUtf8($news->title),
                'content' => $this->cleanUtf8($rewrittenContent . '<br><br><small>তথ্যসূত্র: অনলাইন ডেস্ক</small>'),
                'status'  => 'publish',
                'featured_media' => (int) $imageId, 
                'categories' => [$categoryId], 
            ];

            $wpResponse = Http::withBasicAuth(env('WP_USERNAME'), str_replace(' ', '', env('WP_APP_PASSWORD')))
                ->post($wpBaseUrl . '/wp-json/wp/v2/posts', $postData);

            if ($wpResponse->successful()) {
                $wpPost = $wpResponse->json();
                
                $news->update([
                    'rewritten_content' => $rewrittenContent,
                    'is_posted' => true,
                    'wp_post_id' => $wpPost['id']
                ]);

                $finalMessage = "পোস্ট পাবলিশ হয়েছে! (ID: " . $wpPost['id'] . ") | " . implode(" | ", $processLog);
                return back()->with('success', $finalMessage);

            } else {
                return back()->with('error', 'WP Error: ' . $wpResponse->body());
            }

        } catch (\Exception $e) {
            return back()->with('error', 'SYSTEM ERROR: ' . $e->getMessage());
        }
    }

    private function uploadImageToWP($imageUrl, $title)
    {
        try {
            $imageUrl = preg_replace('/\?.*/', '', $imageUrl); 
            
            $response = Http::withOptions(['verify' => false])
                ->withHeaders([
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer' => 'https://www.google.com/',
                ])
                ->timeout(30)
                ->get($imageUrl);

            if ($response->failed()) {
                return ['success' => false, 'error' => 'DL Fail: ' . $response->status()];
            }

            $imageContent = $response->body();
            $contentType = $response->header('Content-Type');
            if (!$contentType) $contentType = 'image/jpeg';

            $ext = 'jpg';
            if (strpos($contentType, 'png') !== false) $ext = 'png';
            if (strpos($contentType, 'webp') !== false) $ext = 'webp';
            if (strpos($contentType, 'gif') !== false) $ext = 'gif';

            $fileName = 'news-' . time() . '.' . $ext;
            $wpBaseUrl = rtrim(env('WP_SITE_URL'), '/');
            
            $wpResponse = Http::withBasicAuth(env('WP_USERNAME'), str_replace(' ', '', env('WP_APP_PASSWORD')))
                ->withHeaders([
                    'Content-Type' => $contentType,
                    'Content-Disposition' => 'attachment; filename="' . $fileName . '"',
                ])
                ->timeout(60)
                ->withBody($imageContent, $contentType)
                ->post($wpBaseUrl . '/wp-json/wp/v2/media');

            if ($wpResponse->successful()) {
                $mediaId = $wpResponse->json()['id'];
                
                try {
                    Http::withBasicAuth(env('WP_USERNAME'), str_replace(' ', '', env('WP_APP_PASSWORD')))
                        ->post($wpBaseUrl . '/wp-json/wp/v2/media/' . $mediaId, [
                            'alt_text' => $this->cleanUtf8($title),
                            'title'    => $this->cleanUtf8($title)
                        ]);
                } catch (\Exception $e) {}

                return ['success' => true, 'id' => $mediaId];
            } else {
                return ['success' => false, 'error' => 'WP Reject: ' . $wpResponse->status()];
            }

        } catch (\Exception $e) {
            return ['success' => false, 'error' => 'Ex: ' . $e->getMessage()];
        }
    }

    // ✅ আপডেটেড: ডেইলি স্টার ও অন্যান্য এক্সট্রা টেক্সট রিমুভ করা হয়েছে
    private function fetchFullContent($url, $usePuppeteer = false)
    {
        try {
            $htmlContent = null;
            if ($usePuppeteer) {
                $tempFile = storage_path("app/public/temp_detail_" . time() . ".html");
                $scriptPath = base_path("scraper-engine.js");
                // সংক্ষিপ্ত JS - আগের ফুল ভার্সন ব্যবহার করবেন
                $jsCode = <<<'JS'
import puppeteer from 'puppeteer';
import fs from 'fs';
const url = process.argv[2];
const outputFile = process.argv[3];
if (!url || !outputFile) process.exit(1);
(async () => {
  const browser = await puppeteer.launch({
    headless: "new",
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--disable-blink-features=AutomationControlled', '--window-size=1920,1080']
  });
  try {
    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
    await page.setViewport({ width: 1366, height: 768 });
    await page.evaluateOnNewDocument(() => {
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 4 });
        Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
        const getImageData = CanvasRenderingContext2D.prototype.getImageData;
        var noise = {r: -2, g: 0, b: 2};
        CanvasRenderingContext2D.prototype.getImageData = function() {
            const imageData = getImageData.apply(this, arguments);
            for (let i = 0; i < imageData.data.length; i += 4) {
                imageData.data[i] += noise.r;
                imageData.data[i+2] += noise.b;
            }
            return imageData;
        };
    });
    try { await page.goto(url, { waitUntil: 'networkidle2', timeout: 45000 }); } catch (e) { }
    const html = await page.content();
    fs.writeFileSync(outputFile, html);
    await browser.close();
    process.exit(0);
  } catch (error) { await browser.close(); process.exit(1); }
})();
JS;
                file_put_contents($scriptPath, $jsCode);
                $command = "node \"$scriptPath\" \"$url\" \"$tempFile\" \"body\" 2>&1";
                shell_exec($command);
                if (file_exists($tempFile)) {
                    $htmlContent = file_get_contents($tempFile);
                    unlink($tempFile);
                }
            } else {
                $response = Http::withHeaders([
                    'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer' => 'https://www.google.com/',
                ])->timeout(15)->get($url);
                if ($response->successful()) $htmlContent = $response->body();
            }

            if (!$htmlContent) return null;
            if (!str_contains($htmlContent, 'charset')) {
                 $htmlContent = '<meta http-equiv="Content-Type" content="text/html; charset=utf-8">' . $htmlContent;
            }
            $crawler = new Crawler($htmlContent);

            // ১. অপ্রয়োজনীয় ট্যাগ রিমুভ (ডেইলি স্টারের জন্য .related-section, .comments যোগ করা হয়েছে)
            $crawler->filter('script, style, iframe, .advertisement, h1, .title, .date, .time, .meta, .share-buttons, .tags, .comment-section, .print-section, .footer, .copyright, .related-section, .comments-area, .more-content')->each(function (Crawler $crawler) {
                foreach ($crawler as $node) { $node->parentNode->removeChild($node); }
            });
            
            $selectors = ['#img-content', '.lead-news-content', '.details-content', '.article-body', '.details', '#news-details', '.news-details', '.content-details', 'article'];
            foreach ($selectors as $selector) {
                if ($crawler->filter($selector)->count() > 0) {
                    $content = $crawler->filter($selector)->html();
                    $cleanText = strip_tags($content, '<p><br><b><strong><ul><li>');

                    // ২. টেক্সট ক্লিনিং (যমুনা + ডেইলি স্টার ফিক্স)
                    $cleanText = str_replace([
                        'এই ওয়েবসাইটের কোনো লেখা বা ছবি অনুমতি ছাড়া নকল করা বা অন্য কোথাও প্রকাশ করা সম্পূর্ণ বেআইনি।',
                        'Click to comment',
                        'Comments Policy',
                        'Comments',
                        'সম্পর্কিত বিষয়:',
                        'আরও পড়ুন:',
                        'আরও'
                    ], '', $cleanText);

                    $cleanText = preg_replace('/[০-৯]{4}.*?যমুনা টিভি.*?সংরক্ষিত/u', '', $cleanText);
                    $cleanText = preg_replace('/(প্রিন্ট|প্রকাশ)\s*:\s*.*?(এএম|পিএম)/u', '', $cleanText);
                    $cleanText = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $cleanText);
                    
                    if (strlen(trim($cleanText)) > 150) return trim($cleanText);
                }
            }

            // ৩. ফলব্যাক
            if ($crawler->filter('p')->count() > 0) {
                $text = '';
                $crawler->filter('p')->each(function (Crawler $node) use (&$text) {
                    $t = trim($node->text());
                    
                    // ডেইলি স্টার ও যমুনা ফিল্টারিং
                    $garbageWords = [
                        'অনুমতি ছাড়া নকল', 'সর্বস্বত্ব সংরক্ষিত', 'সম্পাদক ও প্রকাশক', 
                        'Click to comment', 'Comments Policy', 'সম্পর্কিত বিষয়', 'আরও'
                    ];
                    
                    $isGarbage = false;
                    foreach ($garbageWords as $word) {
                        if (str_contains($t, $word)) {
                            $isGarbage = true; 
                            break;
                        }
                    }

                    if (strlen($t) > 50 && !$isGarbage && !str_contains($t, 'প্রকাশ:') && !str_contains($t, 'প্রিন্ট:')) { 
                        $text .= "<p>{$t}</p>";
                    }
                });
                return $text ?: null;
            }
            return null;
        } catch (\Exception $e) {
            Log::error("Fetch Error: " . $e->getMessage());
            return null;
        }
    }

    private function rewriteWithDeepSeek($text)
    {
        $apiKey = env('DEEPSEEK_API_KEY');
        $url = "https://api.deepseek.com/chat/completions";
        $text = mb_substr($text, 0, 4000, 'UTF-8');
        $systemPrompt = "You are a senior Bengali news editor. Task 1: Rewrite the news in professional Bengali HTML <p> tags. Task 2: Classify the news into exactly one of these categories: 'Politics', 'International', 'Sports', 'Entertainment', 'Technology', 'Economy', 'Bangladesh', 'Crime', 'Others'. Output MUST be a valid JSON format like this: { \"category\": \"Sports\", \"content\": \"<p>...</p>\" }";

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type' => 'application/json',
        ])->timeout(120)->retry(2, 1000)->post($url, [
            "model" => "deepseek-chat",
            "messages" => [["role" => "system", "content" => $systemPrompt], ["role" => "user", "content" => $text]],
            "temperature" => 0.7,
            "response_format" => ["type" => "json_object"]
        ]);

        if ($response->successful()) {
            $jsonContent = $response->json()['choices'][0]['message']['content'] ?? null;
            if ($jsonContent) {
                $data = json_decode($jsonContent, true);
                return ['content' => $data['content'] ?? $jsonContent, 'category' => $data['category'] ?? 'Others'];
            }
        }
        return null;
    }
}